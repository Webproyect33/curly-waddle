# Biblia de Escritura - Android APK Build

Este proyecto contiene la aplicación completa **Biblia de Escritura** lista para compilar un archivo ejecutable Android (`.apk`) automáticamente a través de **GitHub Actions**.

---

## 🚀 Cómo obtener tu archivo `.apk` en GitHub (Paso a paso)

1. **Crea un repositorio en GitHub** (público o privado):
   - Ve a [GitHub](https://github.com) y crea un nuevo repositorio llamado por ejemplo `biblia-de-escritura`.

2. **Sube estos archivos a tu repositorio**:
   - Puedes arrastrar y soltar los archivos del zip directamente en la interfaz web de GitHub, o mediante comandos git:
     ```bash
     git init
     git add .
     git commit -m "Initial commit - Biblia de Escritura"
     git branch -M main
     git remote add origin https://github.com/TU_USUARIO/TU_REPOSITORIO.git
     git push -u origin main
     ```

3. **Compilación automática en GitHub Actions**:
   - Una vez subido el código, GitHub detectará automáticamente el flujo de trabajo ubicado en `.github/workflows/build-apk.yml`.
   - Ve a la pestaña **Actions** en tu repositorio de GitHub para ver el progreso de la compilación en vivo.

4. **Descargar tu archivo APK**:
   - Cuando la tarea termine (tarda aproximadamente 2 a 3 minutos y mostrará un check verde ✅):
   - Haz clic en la ejecución completada (`Build & Export APK`).
   - Al final de la página, en la sección **Artifacts** (Artefactos), haz clic en **`BibliaDeEscritura-Debug-APK`**.
   - Se descargará un archivo zip que contiene directamente tu archivo `app-debug.apk` listo para instalar en tu celular o tablet Android.

---

## 🛠️ Tecnologías y configuración móvil
- **Framework:** React 19 + TypeScript + Vite + Tailwind CSS.
- **Motor Móvil:** Capacitor 7 (`@capacitor/core`, `@capacitor/cli`, `@capacitor/android`).
- **Audio:** Web Audio API sintético nativo offline (música de inicio, ambiente y sonidos).
- **ID de Aplicación:** `com.bibliadeescritura.app`.
- **Nombre en Pantalla:** `Biblia de Escritura`.
