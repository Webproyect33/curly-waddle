// Web Audio API Synthesizer for "Biblia de Escritura"
// Provides atmospheric fantasy writing ambience, intro fanfare, and notification chimes
// 100% offline, zero external dependencies, no broken links or CORS issues.

class AudioManager {
  private ctx: AudioContext | null = null;
  private isUnlocked: boolean = false;
  private bgmGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private currentBgmOscillators: OscillatorNode[] = [];
  private bgmTimer: NodeJS.Timeout | null = null;
  private rainNoiseNode: AudioNode | null = null;

  public musicMuted: boolean = false;
  public sfxMuted: boolean = false;
  public musicVolume: number = 0.45;
  public sfxVolume: number = 0.5;
  public currentTrack: 'mistico' | 'biblioteca' | 'pergamino' = 'mistico';
  public isBgmPlaying: boolean = false;

  constructor() {
    // Attempt to read persisted settings
    try {
      const stored = localStorage.getItem('biblia_audio_settings');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (typeof parsed.musicMuted === 'boolean') this.musicMuted = parsed.musicMuted;
        if (typeof parsed.sfxMuted === 'boolean') this.sfxMuted = parsed.sfxMuted;
        if (typeof parsed.musicVolume === 'number') this.musicVolume = parsed.musicVolume;
        if (typeof parsed.currentTrack === 'string') this.currentTrack = parsed.currentTrack;
      }
    } catch (e) {
      console.warn('Audio settings load error', e);
    }

    // Auto-unlock AudioContext on first user interaction
    const unlockHandler = () => {
      this.initContext();
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      this.isUnlocked = true;
      window.removeEventListener('click', unlockHandler);
      window.removeEventListener('keydown', unlockHandler);
      window.removeEventListener('touchstart', unlockHandler);
    };

    window.addEventListener('click', unlockHandler);
    window.addEventListener('keydown', unlockHandler);
    window.addEventListener('touchstart', unlockHandler);
  }

  private saveSettings() {
    try {
      localStorage.setItem(
        'biblia_audio_settings',
        JSON.stringify({
          musicMuted: this.musicMuted,
          sfxMuted: this.sfxMuted,
          musicVolume: this.musicVolume,
          currentTrack: this.currentTrack,
        })
      );
    } catch (e) {
      // ignore
    }
  }

  private initContext(): AudioContext | null {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();

        this.bgmGainNode = this.ctx.createGain();
        this.bgmGainNode.gain.value = this.musicMuted ? 0 : this.musicVolume;
        this.bgmGainNode.connect(this.ctx.destination);

        this.sfxGainNode = this.ctx.createGain();
        this.sfxGainNode.gain.value = this.sfxMuted ? 0 : this.sfxVolume;
        this.sfxGainNode.connect(this.ctx.destination);
      }
    }
    return this.ctx;
  }

  public resumeContext() {
    const ctx = this.initContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume();
    }
  }

  // ==========================================
  // INTRO CHIME / OPENING TOME SOUNDTRACK
  // ==========================================
  public playIntroTheme() {
    if (this.musicMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const playNotes = () => {
      const now = ctx.currentTime;
      // Instant fantasy arpeggio: D4, F4, A4, C5, E5, D5 (ethereal spellbook opening)
      const notes = [293.66, 349.23, 440.0, 523.25, 659.25, 587.33];
      // Note 0 starts at 0.0s (instant sound response)
      const delays = [0.0, 0.18, 0.38, 0.60, 0.84, 1.14];

      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        osc.type = i % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + delays[i]);

        // Subtle shimmering vibrato
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1500, now + delays[i]);

        gain.gain.setValueAtTime(0.0001, now + delays[i]);
        // Fast, punchy attack (15ms) so notes speak immediately
        gain.gain.linearRampToValueAtTime(0.24 * (this.musicMuted ? 0 : this.musicVolume), now + delays[i] + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + delays[i] + 1.5);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + delays[i]);
        osc.stop(now + delays[i] + 1.6);
      });

      // Warm backing root note (D2) starting immediately
      const subOsc = ctx.createOscillator();
      const subGain = ctx.createGain();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(73.42, now);
      subGain.gain.setValueAtTime(0.0001, now);
      subGain.gain.linearRampToValueAtTime(0.2 * (this.musicMuted ? 0 : this.musicVolume), now + 0.03);
      subGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.8);

      subOsc.connect(subGain);
      subGain.connect(ctx.destination);
      subOsc.start(now);
      subOsc.stop(now + 2.9);
    };

    if (ctx.state === 'suspended') {
      ctx.resume().then(playNotes).catch(() => {});
    } else {
      playNotes();
    }
  }

  // ==========================================
  // BACKGROUND AMBIENT WRITING MUSIC
  // ==========================================
  public startBgm(track?: 'mistico' | 'biblioteca' | 'pergamino') {
    if (track) this.currentTrack = track;
    this.saveSettings();
    this.stopBgm();

    const ctx = this.initContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume();

    this.isBgmPlaying = true;
    this.scheduleNextAmbientChord();
  }

  private scheduleNextAmbientChord() {
    if (!this.isBgmPlaying) return;
    const ctx = this.initContext();
    if (!ctx) return;

    // Ambient chords progression depending on track
    // Mistico: D minor 9 -> Bb maj 7 -> C add 9 -> A minor 7
    // Biblioteca: F maj 7 -> D min 9 -> G min 7 -> C 7 sus 4
    // Pergamino: A minor -> E minor -> F maj 7 -> G
    let chordFreqs: number[] = [];

    if (this.currentTrack === 'mistico') {
      const progressions = [
        [146.83, 220.0, 261.63, 329.63], // Dm9
        [116.54, 174.61, 233.08, 293.66], // Bbmaj7
        [130.81, 196.0, 293.66, 392.0], // Cadd9
        [110.0, 164.81, 220.0, 261.63], // Am7
      ];
      chordFreqs = progressions[Math.floor(Math.random() * progressions.length)];
    } else if (this.currentTrack === 'biblioteca') {
      const progressions = [
        [174.61, 220.0, 261.63, 329.63], // Fmaj7
        [146.83, 220.0, 261.63, 349.23], // Dm
        [98.0, 146.83, 196.0, 293.66], // Gsus
        [130.81, 196.0, 261.63, 349.23], // Csus
      ];
      chordFreqs = progressions[Math.floor(Math.random() * progressions.length)];
    } else {
      // Pergamino
      const progressions = [
        [110.0, 164.81, 220.0, 329.63], // Am
        [82.41, 123.47, 164.81, 246.94], // Em
        [87.31, 130.81, 174.61, 261.63], // F
        [98.0, 146.83, 196.0, 246.94], // G
      ];
      chordFreqs = progressions[Math.floor(Math.random() * progressions.length)];
    }

    const now = ctx.currentTime;
    const chordDuration = 7.5; // 7.5 seconds of evolving pad

    // Play pad voices
    chordFreqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type = idx === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, now);

      // Lowpass warmth filter
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450 + idx * 120, now);
      filter.Q.setValueAtTime(1.2, now);

      // Very soft swell envelope
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.045 * (this.musicMuted ? 0 : this.musicVolume), now + 2.2);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + chordDuration);

      osc.connect(filter);
      filter.connect(gain);
      if (this.bgmGainNode) {
        gain.connect(this.bgmGainNode);
      } else {
        gain.connect(ctx.destination);
      }

      osc.start(now);
      osc.stop(now + chordDuration + 0.5);

      this.currentBgmOscillators.push(osc);
    });

    // Occasional gentle chime droplet (high celestial overtone)
    if (Math.random() > 0.3) {
      const chimeOsc = ctx.createOscillator();
      const chimeGain = ctx.createGain();
      const chimeFreq = chordFreqs[Math.floor(Math.random() * chordFreqs.length)] * 4;
      const chimeDelay = 1.2 + Math.random() * 3.5;

      chimeOsc.type = 'sine';
      chimeOsc.frequency.setValueAtTime(chimeFreq, now + chimeDelay);

      chimeGain.gain.setValueAtTime(0, now + chimeDelay);
      chimeGain.gain.linearRampToValueAtTime(0.03 * (this.musicMuted ? 0 : this.musicVolume), now + chimeDelay + 0.05);
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, now + chimeDelay + 2.2);

      chimeOsc.connect(chimeGain);
      if (this.bgmGainNode) chimeGain.connect(this.bgmGainNode);
      else chimeGain.connect(ctx.destination);

      chimeOsc.start(now + chimeDelay);
      chimeOsc.stop(now + chimeDelay + 2.3);
      this.currentBgmOscillators.push(chimeOsc);
    }

    // Schedule next chord
    this.bgmTimer = setTimeout(() => {
      this.scheduleNextAmbientChord();
    }, (chordDuration - 1.8) * 1000);
  }

  public stopBgm() {
    this.isBgmPlaying = false;
    if (this.bgmTimer) {
      clearTimeout(this.bgmTimer);
      this.bgmTimer = null;
    }
    this.currentBgmOscillators.forEach((osc) => {
      try {
        osc.stop();
      } catch (e) {
        // ignore already stopped
      }
    });
    this.currentBgmOscillators = [];
  }

  public setMusicMuted(muted: boolean) {
    this.musicMuted = muted;
    this.saveSettings();
    if (this.bgmGainNode && this.ctx) {
      this.bgmGainNode.gain.setValueAtTime(muted ? 0 : this.musicVolume, this.ctx.currentTime);
    }
  }

  public setMusicVolume(vol: number) {
    this.musicVolume = Math.max(0, Math.min(1, vol));
    this.saveSettings();
    if (this.bgmGainNode && this.ctx && !this.musicMuted) {
      this.bgmGainNode.gain.setValueAtTime(this.musicVolume, this.ctx.currentTime);
    }
  }

  public setSfxMuted(muted: boolean) {
    this.sfxMuted = muted;
    this.saveSettings();
    if (this.sfxGainNode && this.ctx) {
      this.sfxGainNode.gain.setValueAtTime(muted ? 0 : this.sfxVolume, this.ctx.currentTime);
    }
  }

  // ==========================================
  // NOTIFICATION & ACTION CHIMES
  // ==========================================
  public playNotificationSound(type: 'ok' | 'warn' | 'err' = 'ok') {
    if (this.sfxMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume();

    const now = ctx.currentTime;

    if (type === 'ok') {
      // Pleasant dual tone chime (F5 -> C6)
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(698.46, now); // F5
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1046.5, now + 0.08); // C6

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.12 * this.sfxVolume, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc1.stop(now + 0.25);
      osc2.start(now + 0.08);
      osc2.stop(now + 0.48);
    } else if (type === 'warn') {
      // Gentle warning chime (A4 -> E4)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440.0, now);
      osc.frequency.linearRampToValueAtTime(329.63, now + 0.2);

      gain.gain.setValueAtTime(0.14 * this.sfxVolume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.36);
    } else {
      // Error dull double thump
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(80, now + 0.2);

      gain.gain.setValueAtTime(0.1 * this.sfxVolume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.26);
    }
  }

  // Soft page flip sound for opening modals
  public playPageFlip() {
    if (this.sfxMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume();

    const now = ctx.currentTime;
    const bufferSize = ctx.sampleRate * 0.08;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.35));
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1200, now);
    filter.Q.setValueAtTime(2.5, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.06 * this.sfxVolume, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    noise.start(now);
    noise.stop(now + 0.1);
  }
}

export const audioManager = new AudioManager();
