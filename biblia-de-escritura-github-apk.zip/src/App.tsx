import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  BookOpen,
  Users,
  GitFork,
  Settings,
  Plus,
  Search,
  MoreVertical,
  ChevronDown,
  Trash2,
  Edit3,
  Copy,
  ExternalLink,
  Download,
  Upload,
  FileText,
  MapPin,
  Sparkles,
  ArrowRight,
  RefreshCw,
  AlertTriangle,
  Heart,
  Shield,
  Briefcase,
  Cake,
  Feather,
  Compass,
  X,
  Check,
  Volume2,
  VolumeX,
  Music,
  Bell,
  BellOff,
  Palette,
  Play
} from 'lucide-react';
import { audioManager } from './utils/audio';

// =========================================================
// TYPES & MODEL
// =========================================================
export interface Relacion {
  id: string;
  destinoId: string;
  tipo: string;
  notas?: string;
}

export interface Personaje {
  id: string;
  nombre: string;
  rol?: string;
  edad?: string;
  origen?: string;
  ocupacion?: string;
  aliados?: string;
  caracteristicas?: string;
  historia?: string;
  notas?: string;
  relaciones?: Relacion[];
}

export interface Capitulo {
  id: string;
  numero: number;
  titulo: string;
  resumen: string;
  estado: 'Borrador' | 'En revisión' | 'Finalizado';
  personajesIds?: string[];
  notas?: string;
}

export interface Lugar {
  id: string;
  nombre: string;
  tipo: string;
  descripcion: string;
  atmosfera?: string;
  notas?: string;
}

export interface Novela {
  id: string;
  nombre: string;
  color: string;
  genero?: string;
  sinopsis?: string;
  personajes: Personaje[];
  capitulos?: Capitulo[];
  lugares?: Lugar[];
}

interface AppState {
  novelas: Novela[];
  novelaActivaId: string | null;
  ultimoLibroId: string | null;
  detallesAbiertos: Record<string, boolean>;
  vistaActiva: 'home' | 'conexiones' | 'trama' | 'lugares' | 'config';
}

export interface TemaItem {
  id: string;
  nombre: string;
  descripcion: string;
  bgPreview: string;
  panelPreview: string;
  accentPreview: string;
  accent2Preview: string;
  tag: string;
}

export const TEMAS_DISPONIBLES: TemaItem[] = [
  {
    id: 'medianoche',
    nombre: 'Medianoche Violeta',
    descripcion: 'Púrpura arcano y rosa neón sobre azul medianoche profundo.',
    bgPreview: '#1a1a24',
    panelPreview: '#252533',
    accentPreview: '#7c5cff',
    accent2Preview: '#ff7ac6',
    tag: 'Clásico'
  },
  {
    id: 'papiro',
    nombre: 'Papiro & Pergamino',
    descripcion: 'Tono sepia oscuro cálido con acentos en oro viejo y ámbar de manuscrito.',
    bgPreview: '#1c1815',
    panelPreview: '#27221d',
    accentPreview: '#d97706',
    accent2Preview: '#f59e0b',
    tag: 'Medieval'
  },
  {
    id: 'esmeralda',
    nombre: 'Bosque Élfico',
    descripcion: 'Fantasía nocturna en verde bosque con resplandores de jade y esmeralda.',
    bgPreview: '#0e1814',
    panelPreview: '#162520',
    accentPreview: '#10b981',
    accent2Preview: '#34d399',
    tag: 'Fantasía'
  },
  {
    id: 'gotico',
    nombre: 'Biblioteca Gótica',
    descripcion: 'Carbón, piedra y sombras con acentos en azul espectral y plata.',
    bgPreview: '#0f1016',
    panelPreview: '#181922',
    accentPreview: '#38bdf8',
    accent2Preview: '#818cf8',
    tag: 'Misterio'
  },
  {
    id: 'crepusculo',
    nombre: 'Crepúsculo Carmesí',
    descripcion: 'Borgoña y terciopelo oscuro con tonos frambuesa y coral místico.',
    bgPreview: '#1c1218',
    panelPreview: '#281923',
    accentPreview: '#f43f5e',
    accent2Preview: '#fb7185',
    tag: 'Pasión'
  },
  {
    id: 'pergamino_claro',
    nombre: 'Luz de Vela (Modo Claro)',
    descripcion: 'Papel marfil suave, paneles blancos y tinta violeta para lectura despejada.',
    bgPreview: '#f5f2ea',
    panelPreview: '#ffffff',
    accentPreview: '#7c5cff',
    accent2Preview: '#b45309',
    tag: 'Diurno'
  },
  {
    id: 'cyber',
    nombre: 'Galaxia Neón',
    descripcion: 'Azul abisal con reflejos cian estelar y magenta futurista.',
    bgPreview: '#0b1021',
    panelPreview: '#131a35',
    accentPreview: '#06b6d4',
    accent2Preview: '#f43f5e',
    tag: 'Sci-Fi'
  }
];

const STORAGE_KEY = 'biblia_escritura_v1';
const LEGACY_STORAGE_KEY = 'biblia_personajes_v6';

const COLORES = [
  '#7c5cff',
  '#ff7ac6',
  '#4ade80',
  '#facc15',
  '#38bdf8',
  '#fb923c',
  '#f87171',
  '#a78bfa',
  '#34d399',
  '#ec4899',
  '#10b981',
  '#6366f1'
];

export const WORKFLOW_YAML_APK = `name: Compilar y Generar APK Android

on:
  push:
    branches: [ '**' ]
  pull_request:
    branches: [ '**' ]
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build-apk:
    name: Compilar APK con Capacitor y Gradle
    runs-on: ubuntu-latest

    steps:
      - name: 1. Descargar repositorio
        uses: actions/checkout@v4

      - name: 2. Descomprimir archivo ZIP (si se subió en formato .zip)
        run: |
          echo "=== Verificando si existe archivo ZIP ==="
          ZIP_FOUND=$(find . -maxdepth 2 -name "*.zip" | head -n 1)
          if [ -n "$ZIP_FOUND" ]; then
            echo "Archivo ZIP detectado: $ZIP_FOUND"
            mkdir -p __unpacked_temp
            unzip -q -o "$ZIP_FOUND" -d __unpacked_temp
            if [ -f "__unpacked_temp/package.json" ]; then
              cp -rf __unpacked_temp/* .
            else
              SUBFOLDER=$(find __unpacked_temp -mindepth 1 -maxdepth 1 -type d | head -n 1)
              if [ -n "$SUBFOLDER" ] && [ -f "$SUBFOLDER/package.json" ]; then
                echo "Moviendo archivos desde subcarpeta: $SUBFOLDER"
                cp -rf "$SUBFOLDER"/* .
              else
                cp -rf __unpacked_temp/* .
              fi
            fi
            rm -rf __unpacked_temp
            echo "Archivos extraídos correctamente."
          else
            echo "Usando el código fuente directamente."
          fi
          ls -la

      - name: 3. Configurar Node.js 22 (LTS - Requerido por Capacitor 8)
        uses: actions/setup-node@v4
        with:
          node-version: 22

      - name: 4. Configurar Java JDK 21 (Requerido por Capacitor 8)
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'

      - name: 5. Configurar Android SDK y Licencias
        run: |
          export ANDROID_HOME=\${ANDROID_HOME:-/usr/local/lib/android/sdk}
          echo "ANDROID_HOME=$ANDROID_HOME" >> $GITHUB_ENV
          echo "ANDROID_SDK_ROOT=$ANDROID_HOME" >> $GITHUB_ENV
          if [ -d "$ANDROID_HOME/cmdline-tools/latest/bin" ]; then
            echo "$ANDROID_HOME/cmdline-tools/latest/bin" >> $GITHUB_PATH
          fi
          if [ -d "$ANDROID_HOME/platform-tools" ]; then
            echo "$ANDROID_HOME/platform-tools" >> $GITHUB_PATH
          fi
          yes | sdkmanager --licenses 2>/dev/null || true
          yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses 2>/dev/null || true

      - name: 6. Instalar dependencias del proyecto
        run: |
          npm install --legacy-peer-deps

      - name: 7. Compilar aplicación Web (Vite)
        run: |
          npm run build

      - name: 8. Sincronizar proyecto Android con Capacitor
        run: |
          mkdir -p android/app/src/main/assets/public
          if [ -d "dist" ]; then
            echo "Copiando assets de la aplicación web a Android..."
            cp -rf dist/* android/app/src/main/assets/public/
          fi
          if [ -f "capacitor.config.json" ]; then
            cp -f capacitor.config.json android/app/src/main/assets/capacitor.config.json
          fi
          echo "Sincronizando plugins de Capacitor..."
          npx cap sync android || echo "Sincronización directa completada con éxito."


      - name: 9. Compilar APK con Gradle
        run: |
          cd android
          chmod +x ./gradlew
          ./gradlew assembleDebug --no-daemon --stacktrace

      - name: 10. Subir archivo APK listo para descargar
        uses: actions/upload-artifact@v4
        with:
          name: BibliaDeEscritura-Instalador-APK
          path: android/app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
          retention-days: 30
`;

const TIPOS_RELACION_PREDEFINIDOS = [
  'Aliado / Compañero',
  'Rival / Enemigo',
  'Familia / Pariente',
  'Romance / Interés amoroso',
  'Mentor / Maestro',
  'Aprendiz / Pupilo',
  'Amistad estrecha',
  'Subordinado / Empleado',
  'Líder / Superior',
  'Deuda / Juramento'
];

function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function iniciales(nombre: string): string {
  if (!nombre) return '?';
  const partes = nombre.trim().split(/\s+/);
  if (partes.length === 1) return partes[0].charAt(0).toUpperCase();
  return (partes[0].charAt(0) + partes[partes.length - 1].charAt(0)).toUpperCase();
}

// Sample initial data for first-time writers
const LIBRO_EJEMPLO: Novela = {
  id: 'libro_ejemplo_1',
  nombre: 'La Canción de las Cenizas',
  genero: 'Fantasía Oscura / Aventura',
  sinopsis: 'En un imperio desgarrado por la niebla espectral, una hechicera proscrita y un capitán deshonrado descubren la conspiración que amenaza consumir el último bastión humano.',
  color: '#7c5cff',
  personajes: [
    {
      id: 'char_aria',
      nombre: 'Aria Vane',
      rol: 'Protagonista',
      edad: '24 inviernos',
      origen: 'Bastión del Valle Umbrío',
      ocupacion: 'Hechicera proscrita y alquimista',
      aliados: 'Kaelen Rorik, Gretta la Tabernera',
      caracteristicas: 'Ojos violetas que destellan al invocar frío; cabello azabache trenzado con plata; cicatriz en la muñeca derecha. Temperamento reservado pero de voluntad implacable.',
      historia: 'Hija de un erudito ejecutado por la Inquisición Arcana. Huyó a los páramos del norte con el diario de su padre y un colgante de piedra lunar que aún no comprende del todo.',
      notas: 'Guarda un frasco de cenizas ancestrales que reacciona ante la presencia de criaturas sombrías.',
      relaciones: [
        { id: 'rel_1', destinoId: 'char_kaelen', tipo: 'Aliado / Compañero', notas: 'Pacto de mutua protección tras salvarle en el Paso de los Cuervos' },
        { id: 'rel_2', destinoId: 'char_sylas', tipo: 'Rival / Enemigo', notas: 'Sylas busca arrestarla para cobrar la recompensa imperial' }
      ]
    },
    {
      id: 'char_kaelen',
      nombre: 'Kaelen Rorik',
      rol: 'Coprotagonista',
      edad: '36 años',
      origen: 'Ciudadela de Hierro',
      ocupacion: 'Ex-capitán de la Guardia Imperial',
      aliados: 'Aria Vane',
      caracteristicas: 'Alto, complexión fornida curtida en diez campañas. Mandíbula cuadrada, barba recortada y mirada alerta de veterano de guerra.',
      historia: 'Despojado de su rango tras negarse a acatar la orden de masacrar a civiles sospechosos de brujería. Ahora busca redimir su juramento protegiendo a los inocentes.',
      notas: 'Carga un espadón con el emblema de su antigua orden borrado a martillazos.',
      relaciones: [
        { id: 'rel_3', destinoId: 'char_aria', tipo: 'Aliado / Compañero', notas: 'Confía en su juicio a pesar de la desconfianza general hacia la magia' },
        { id: 'rel_4', destinoId: 'char_sylas', tipo: 'Rival / Enemigo', notas: 'Antiguos compañeros en la guardia; Sylas lo considera un traidor' }
      ]
    },
    {
      id: 'char_sylas',
      nombre: 'Sylas Thorne',
      rol: 'Antagonista',
      edad: '39 años',
      origen: 'Corte Imperial de Solstice',
      ocupacion: 'Inquisidor de la Orden Purificadora',
      aliados: 'Guardia Imperial, Alto Concilio',
      caracteristicas: 'Delgado, elegante, túnica carmesí con hombreras de bronce pulido. Mirada gélida y sonrisa educada que oculta crueldad metódica.',
      historia: 'Convencido de que cualquier manifestación de magia no regulada conducirá al cataclismo. Cree sinceramente que el fin justifica los medios.',
      notas: 'Tiene espías en todas las tabernas importantes de la ruta norte.',
      relaciones: [
        { id: 'rel_5', destinoId: 'char_aria', tipo: 'Rival / Enemigo', notas: 'Orden de captura viva o muerta' }
      ]
    }
  ],
  capitulos: [
    {
      id: 'cap_1',
      numero: 1,
      titulo: 'Cenizas en el Viento',
      resumen: 'Aria escapa por los techos del mercado invernal cuando patrullas inquisitoriales asaltan su taller clandestino.',
      estado: 'Finalizado',
      personajesIds: ['char_aria', 'char_sylas'],
      notas: 'Establecer la atmósfera gélida y el peligro constante de usar magia en público.'
    },
    {
      id: 'cap_2',
      numero: 2,
      titulo: 'El Encuentro en el Paso',
      resumen: 'Kaelen interviene en una emboscada en el Paso de los Cuervos salvando a Aria a cambio de un favor que cambiará su destino.',
      estado: 'En revisión',
      personajesIds: ['char_aria', 'char_kaelen'],
      notas: 'Tensión inicial: Kaelen duda de sus intenciones arcanas.'
    }
  ],
  lugares: [
    {
      id: 'lug_1',
      nombre: 'Ciudadela de Hierro',
      tipo: 'Fortaleza & Capital militar',
      descripcion: 'Imponente bastión erigido sobre riscos escarpados. Murallas de roca volcánica y torres coronadas con balistas gigantes.',
      atmosfera: 'Olor a carbón, humo de forjas día y noche, constante redoble de botas metálicas.'
    },
    {
      id: 'lug_2',
      nombre: 'Paso de los Cuervos',
      tipo: 'Ruta montañosa peligrosa',
      descripcion: 'Desfiladero estrecho perpetuamente azotado por ventiscas donde bandidos y bestias acechan a los carruajes.',
      atmosfera: 'Silbato fantasmal del viento helado, niebla baja y crujido de hielo.'
    }
  ]
};

export default function App() {
  // Screen state
  const [screen, setScreen] = useState<'logo' | 'splash' | 'inicio' | 'app'>('logo');
  const [splashPct, setSplashPct] = useState(0);
  const [splashMsg, setSplashMsg] = useState('Iniciando...');

  // Core App State
  const [state, setState] = useState<AppState>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.novelas) && parsed.novelas.length > 0) {
          return {
            novelas: parsed.novelas,
            novelaActivaId: parsed.novelaActivaId || parsed.novelas[0].id,
            ultimoLibroId: parsed.ultimoLibroId || parsed.novelas[0].id,
            detallesAbiertos: parsed.detallesAbiertos || {},
            vistaActiva: parsed.vistaActiva || 'home'
          };
        }
      }

      // Check legacy v6 data
      const legacy = localStorage.getItem(LEGACY_STORAGE_KEY);
      if (legacy) {
        const parsedLegacy = JSON.parse(legacy);
        if (parsedLegacy && Array.isArray(parsedLegacy.novelas) && parsedLegacy.novelas.length > 0) {
          return {
            novelas: parsedLegacy.novelas,
            novelaActivaId: parsedLegacy.novelaActivaId || parsedLegacy.novelas[0].id,
            ultimoLibroId: parsedLegacy.ultimoLibroId || parsedLegacy.novelas[0].id,
            detallesAbiertos: parsedLegacy.detallesAbiertos || {},
            vistaActiva: 'home'
          };
        }
      }
    } catch (e) {
      console.warn('Error reading stored state:', e);
    }

    // Default with sample book
    return {
      novelas: [LIBRO_EJEMPLO],
      novelaActivaId: LIBRO_EJEMPLO.id,
      ultimoLibroId: LIBRO_EJEMPLO.id,
      detallesAbiertos: { char_aria: true },
      vistaActiva: 'home'
    };
  });

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Error saving state:', e);
    }
  }, [state]);

  // Theme State
  const [tema, setTema] = useState<string>(() => {
    try {
      return localStorage.getItem('biblia_tema') || 'medianoche';
    } catch {
      return 'medianoche';
    }
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', tema);
    try {
      localStorage.setItem('biblia_tema', tema);
    } catch (e) {}
  }, [tema]);

  // Audio State
  const [musicaMuted, setMusicaMuted] = useState<boolean>(() => audioManager.musicMuted);
  const [sonidosMuted, setSonidosMuted] = useState<boolean>(() => audioManager.sfxMuted);
  const [musicaVolumen, setMusicaVolumen] = useState<number>(() => audioManager.musicVolume);
  const [pistaActual, setPistaActual] = useState<'mistico' | 'biblioteca' | 'pergamino'>(
    () => audioManager.currentTrack
  );

  // Toast feedback with notification sound
  const [toast, setToast] = useState<{ msg: string; type?: 'ok' | 'warn' | 'err' } | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = (msg: string, type: 'ok' | 'warn' | 'err' = 'ok') => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToast({ msg, type });
    audioManager.playNotificationSound(type);
    toastTimeoutRef.current = setTimeout(() => {
      setToast(null);
    }, 2600);
  };

  // Search & Filters
  const [busqueda, setBusqueda] = useState('');
  const [filtroRol, setFiltroRol] = useState<string>('todos');

  // Modals
  const [modalNuevoPersonaje, setModalNuevoPersonaje] = useState(false);
  const [modalEditarPersonaje, setModalEditarPersonaje] = useState<Personaje | null>(null);
  const [modalMoverPersonaje, setModalMoverPersonaje] = useState<Personaje | null>(null);
  const [modalEliminarPersonaje, setModalEliminarPersonaje] = useState<Personaje | null>(null);
  const [modalRelaciones, setModalRelaciones] = useState<Personaje | null>(null);
  const [modalNuevoLibro, setModalNuevoLibro] = useState(false);
  const [modalRegistroLibros, setModalRegistroLibros] = useState(false);
  const [modalNuevoCapitulo, setModalNuevoCapitulo] = useState(false);
  const [modalEditarCapitulo, setModalEditarCapitulo] = useState<Capitulo | null>(null);
  const [modalNuevoLugar, setModalNuevoLugar] = useState(false);
  const [modalEditarLugar, setModalEditarLugar] = useState<Lugar | null>(null);

  // Context Menu
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; pId: string } | null>(null);

  // Active Novel Helper
  const novelaActiva = useMemo(() => {
    return state.novelas.find((n) => n.id === state.novelaActivaId) || null;
  }, [state.novelas, state.novelaActivaId]);

  // Initial Splash Sequence
  useEffect(() => {
    // 1. Logo screen automatically transitions swiftly if user doesn't tap
    const tLogo = setTimeout(() => {
      setScreen('splash');

      const mensajes = [
        'Iniciando Biblia de Escritura...',
        'Organizando tus universos literarios...',
        'Recuperando el elenco de personajes...',
        'Todo listo para escribir ✨'
      ];

      let prog = 0;
      let msgIdx = 0;

      const intProg = setInterval(() => {
        prog += 25;
        if (prog >= 100) {
          prog = 100;
          setSplashPct(100);
          setSplashMsg(mensajes[mensajes.length - 1]);
          clearInterval(intProg);
          setTimeout(() => {
            setScreen('inicio');
          }, 200);
        } else {
          setSplashPct(prog);
          if (msgIdx < mensajes.length - 1) {
            msgIdx++;
            setSplashMsg(mensajes[msgIdx]);
          }
        }
      }, 70);
    }, 900);

    return () => clearTimeout(tLogo);
  }, []);

  // Auto-start ambient background music when application is open
  useEffect(() => {
    if ((screen === 'inicio' || screen === 'app') && !musicaMuted) {
      audioManager.resumeContext();
      if (!audioManager.isBgmPlaying) {
        audioManager.startBgm(pistaActual);
      }
    }
  }, [screen, musicaMuted, pistaActual]);

  // Instant trigger on first user gesture: warm up audio and play intro fanfare immediately
  useEffect(() => {
    let triggered = false;
    const handleInstantStart = () => {
      if (triggered) return;
      triggered = true;
      audioManager.resumeContext();
      if (!musicaMuted && (screen === 'logo' || screen === 'splash')) {
        audioManager.playIntroTheme();
      }
    };

    window.addEventListener('pointerdown', handleInstantStart, { passive: true, once: true });
    window.addEventListener('touchstart', handleInstantStart, { passive: true, once: true });
    window.addEventListener('click', handleInstantStart, { passive: true, once: true });
    window.addEventListener('keydown', handleInstantStart, { passive: true, once: true });

    return () => {
      window.removeEventListener('pointerdown', handleInstantStart);
      window.removeEventListener('touchstart', handleInstantStart);
      window.removeEventListener('click', handleInstantStart);
      window.removeEventListener('keydown', handleInstantStart);
    };
  }, [musicaMuted, screen]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        showToast('💾 Todo guardado correctamente');
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        if (screen === 'app' && state.vistaActiva === 'home') {
          setModalNuevoPersonaje(true);
        }
      }
      if (e.key === 'Escape') {
        setCtxMenu(null);
        setModalNuevoPersonaje(false);
        setModalEditarPersonaje(null);
        setModalMoverPersonaje(null);
        setModalEliminarPersonaje(null);
        setModalRelaciones(null);
        setModalNuevoLibro(false);
        setModalNuevoCapitulo(false);
        setModalEditarCapitulo(null);
        setModalNuevoLugar(false);
        setModalEditarLugar(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [screen, state.vistaActiva]);

  // Dismiss context menu on click outside
  useEffect(() => {
    const handleClickOutside = () => {
      if (ctxMenu) setCtxMenu(null);
    };
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, [ctxMenu]);

  // Actions
  const abrirLibro = (id: string) => {
    const n = state.novelas.find((x) => x.id === id);
    if (!n) {
      showToast('Ese libro no existe', 'err');
      return;
    }
    setState((prev) => ({
      ...prev,
      novelaActivaId: id,
      ultimoLibroId: id,
      vistaActiva: 'home'
    }));
    setScreen('app');
    showToast(`📖 Abierto: "${n.nombre}"`);
  };

  const cambiarVista = (vista: AppState['vistaActiva']) => {
    setState((prev) => ({ ...prev, vistaActiva: vista }));
    setCtxMenu(null);
  };

  const toggleDetallePersonaje = (pId: string) => {
    setState((prev) => ({
      ...prev,
      detallesAbiertos: {
        ...prev.detallesAbiertos,
        [pId]: !prev.detallesAbiertos[pId]
      }
    }));
  };

  const crearNuevoLibro = (nombre: string, genero?: string, sinopsis?: string) => {
    if (!nombre.trim()) return;
    const usados = state.novelas.map((n) => n.color);
    const libre = COLORES.find((c) => !usados.includes(c)) || COLORES[state.novelas.length % COLORES.length];

    const nuevo: Novela = {
      id: uid(),
      nombre: nombre.trim(),
      genero: genero?.trim(),
      sinopsis: sinopsis?.trim(),
      color: libre,
      personajes: [],
      capitulos: [],
      lugares: []
    };

    setState((prev) => ({
      ...prev,
      novelas: [...prev.novelas, nuevo],
      novelaActivaId: nuevo.id,
      ultimoLibroId: nuevo.id,
      vistaActiva: 'home'
    }));
    setModalNuevoLibro(false);
    setModalRegistroLibros(false);
    setScreen('app');
    showToast(`✨ Nuevo libro creado: "${nuevo.nombre}"`);
  };

  const renombrarLibro = (id: string) => {
    const n = state.novelas.find((x) => x.id === id);
    if (!n) return;
    const nuevo = prompt('Nuevo nombre para el libro:', n.nombre);
    if (nuevo && nuevo.trim()) {
      setState((prev) => ({
        ...prev,
        novelas: prev.novelas.map((x) => (x.id === id ? { ...x, nombre: nuevo.trim() } : x))
      }));
      showToast('✏️ Nombre de libro actualizado');
    }
  };

  const borrarLibro = (id: string) => {
    const n = state.novelas.find((x) => x.id === id);
    if (!n) return;
    if (!confirm(`¿Eliminar el libro "${n.nombre}" y todos sus personajes, capítulos y lugares?`)) return;

    setState((prev) => {
      const rest = prev.novelas.filter((x) => x.id !== id);
      const nextActivo = rest.length > 0 ? rest[0].id : null;
      return {
        ...prev,
        novelas: rest,
        novelaActivaId: nextActivo,
        ultimoLibroId: nextActivo
      };
    });

    showToast('🗑️ Libro eliminado', 'warn');
  };

  // Character Management
  const guardarNuevoPersonaje = (data: Partial<Personaje>) => {
    if (!novelaActiva || !data.nombre?.trim()) {
      showToast('Por favor escribe al menos un nombre', 'warn');
      return;
    }
    const nuevo: Personaje = {
      id: uid(),
      nombre: data.nombre.trim(),
      rol: data.rol?.trim() || '',
      edad: data.edad?.trim() || '',
      origen: data.origen?.trim() || '',
      ocupacion: data.ocupacion?.trim() || '',
      aliados: data.aliados?.trim() || '',
      caracteristicas: data.caracteristicas?.trim() || '',
      historia: data.historia?.trim() || '',
      notas: data.notas?.trim() || '',
      relaciones: []
    };

    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) =>
        n.id === prev.novelaActivaId ? { ...n, personajes: [nuevo, ...n.personajes] } : n
      ),
      detallesAbiertos: { ...prev.detallesAbiertos, [nuevo.id]: true }
    }));

    setModalNuevoPersonaje(false);
    showToast(`✍️ Personaje "${nuevo.nombre}" añadido`);
  };

  const guardarEdicionPersonaje = (data: Personaje) => {
    if (!novelaActiva || !data.nombre.trim()) return;

    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) =>
        n.id === prev.novelaActivaId
          ? {
              ...n,
              personajes: n.personajes.map((p) => (p.id === data.id ? { ...p, ...data } : p))
            }
          : n
      )
    }));

    setModalEditarPersonaje(null);
    showToast('✅ Ficha de personaje actualizada');
  };

  const duplicarPersonaje = (pId: string) => {
    if (!novelaActiva) return;
    const target = novelaActiva.personajes.find((p) => p.id === pId);
    if (!target) return;

    const copia: Personaje = {
      ...JSON.parse(JSON.stringify(target)),
      id: uid(),
      nombre: `${target.nombre} (Copia)`,
      relaciones: []
    };

    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) =>
        n.id === prev.novelaActivaId ? { ...n, personajes: [copia, ...n.personajes] } : n
      )
    }));

    showToast('📋 Personaje duplicado');
  };

  const confirmarEliminarPersonaje = () => {
    if (!modalEliminarPersonaje || !novelaActiva) return;
    const pId = modalEliminarPersonaje.id;
    const nombre = modalEliminarPersonaje.nombre;

    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) => {
        if (n.id !== prev.novelaActivaId) return n;
        const cleaned = n.personajes
          .filter((p) => p.id !== pId)
          .map((p) => ({
            ...p,
            relaciones: (p.relaciones || []).filter((r) => r.destinoId !== pId)
          }));
        return { ...n, personajes: cleaned };
      })
    }));

    setModalEliminarPersonaje(null);
    showToast(`🗑️ "${nombre}" eliminado`, 'warn');
  };

  const moverPersonajeDestino = (destinoLibroId: string) => {
    if (!modalMoverPersonaje || !novelaActiva) return;
    const pId = modalMoverPersonaje.id;
    const origenNovela = novelaActiva;
    const destinoNovela = state.novelas.find((n) => n.id === destinoLibroId);
    if (!destinoNovela) return;

    const char = origenNovela.personajes.find((p) => p.id === pId);
    if (!char) return;

    const charClean: Personaje = {
      ...char,
      relaciones: [] // Reset relations as destination novel characters are different
    };

    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) => {
        if (n.id === origenNovela.id) {
          return {
            ...n,
            personajes: n.personajes
              .filter((p) => p.id !== pId)
              .map((p) => ({
                ...p,
                relaciones: (p.relaciones || []).filter((r) => r.destinoId !== pId)
              }))
          };
        }
        if (n.id === destinoNovela.id) {
          return {
            ...n,
            personajes: [charClean, ...n.personajes]
          };
        }
        return n;
      }),
      novelaActivaId: destinoNovela.id,
      ultimoLibroId: destinoNovela.id
    }));

    setModalMoverPersonaje(null);
    showToast(`📁 "${char.nombre}" transferido a "${destinoNovela.nombre}"`);
  };

  // Relations Management
  const agregarRelacion = (origenId: string, destinoId: string, tipo: string, notas?: string) => {
    if (!novelaActiva || !origenId || !destinoId) return;

    const nuevaRel: Relacion = {
      id: uid(),
      destinoId,
      tipo: tipo.trim() || 'Vínculo',
      notas: notas?.trim()
    };

    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) => {
        if (n.id !== prev.novelaActivaId) return n;
        return {
          ...n,
          personajes: n.personajes.map((p) => {
            if (p.id === origenId) {
              const rels = p.relaciones || [];
              // Prevent exact duplicate link
              const filtradas = rels.filter((r) => r.destinoId !== destinoId);
              return { ...p, relaciones: [...filtradas, nuevaRel] };
            }
            return p;
          })
        };
      })
    }));

    // If modalRelaciones is open, update its reference
    if (modalRelaciones && modalRelaciones.id === origenId) {
      setModalRelaciones((prev) => {
        if (!prev) return null;
        const rels = prev.relaciones || [];
        return {
          ...prev,
          relaciones: [...rels.filter((r) => r.destinoId !== destinoId), nuevaRel]
        };
      });
    }

    showToast('🔗 Relación vinculada con éxito');
  };

  const eliminarRelacion = (origenId: string, relId: string) => {
    if (!novelaActiva) return;

    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) => {
        if (n.id !== prev.novelaActivaId) return n;
        return {
          ...n,
          personajes: n.personajes.map((p) => {
            if (p.id === origenId) {
              return { ...p, relaciones: (p.relaciones || []).filter((r) => r.id !== relId) };
            }
            return p;
          })
        };
      })
    }));

    if (modalRelaciones && modalRelaciones.id === origenId) {
      setModalRelaciones((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          relaciones: (prev.relaciones || []).filter((r) => r.id !== relId)
        };
      });
    }

    showToast('Relación eliminada');
  };

  // Chapter Management
  const guardarCapitulo = (data: Partial<Capitulo>) => {
    if (!novelaActiva || !data.titulo?.trim()) return;

    if (modalEditarCapitulo) {
      setState((prev) => ({
        ...prev,
        novelas: prev.novelas.map((n) => {
          if (n.id !== prev.novelaActivaId) return n;
          return {
            ...n,
            capitulos: (n.capitulos || []).map((c) =>
              c.id === modalEditarCapitulo.id ? { ...c, ...data } as Capitulo : c
            )
          };
        })
      }));
      setModalEditarCapitulo(null);
      showToast('Capítulo actualizado');
    } else {
      const proximoNum = (novelaActiva.capitulos?.length || 0) + 1;
      const nuevo: Capitulo = {
        id: uid(),
        numero: data.numero || proximoNum,
        titulo: data.titulo.trim(),
        resumen: data.resumen?.trim() || '',
        estado: data.estado || 'Borrador',
        personajesIds: data.personajesIds || [],
        notas: data.notas?.trim()
      };

      setState((prev) => ({
        ...prev,
        novelas: prev.novelas.map((n) => {
          if (n.id !== prev.novelaActivaId) return n;
          return {
            ...n,
            capitulos: [...(n.capitulos || []), nuevo]
          };
        })
      }));
      setModalNuevoCapitulo(false);
      showToast('📜 Nuevo capítulo añadido');
    }
  };

  const borrarCapitulo = (cId: string) => {
    if (!novelaActiva || !confirm('¿Eliminar este capítulo de la trama?')) return;
    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) => {
        if (n.id !== prev.novelaActivaId) return n;
        return {
          ...n,
          capitulos: (n.capitulos || []).filter((c) => c.id !== cId)
        };
      })
    }));
    showToast('Capítulo eliminado');
  };

  // Location Management
  const guardarLugar = (data: Partial<Lugar>) => {
    if (!novelaActiva || !data.nombre?.trim()) return;

    if (modalEditarLugar) {
      setState((prev) => ({
        ...prev,
        novelas: prev.novelas.map((n) => {
          if (n.id !== prev.novelaActivaId) return n;
          return {
            ...n,
            lugares: (n.lugares || []).map((l) =>
              l.id === modalEditarLugar.id ? { ...l, ...data } as Lugar : l
            )
          };
        })
      }));
      setModalEditarLugar(null);
      showToast('Lugar actualizado');
    } else {
      const nuevo: Lugar = {
        id: uid(),
        nombre: data.nombre.trim(),
        tipo: data.tipo?.trim() || 'Ubicación',
        descripcion: data.descripcion?.trim() || '',
        atmosfera: data.atmosfera?.trim() || '',
        notas: data.notas?.trim()
      };

      setState((prev) => ({
        ...prev,
        novelas: prev.novelas.map((n) => {
          if (n.id !== prev.novelaActivaId) return n;
          return {
            ...n,
            lugares: [...(n.lugares || []), nuevo]
          };
        })
      }));
      setModalNuevoLugar(false);
      showToast('🏰 Nuevo lugar registrado');
    }
  };

  const borrarLugar = (lId: string) => {
    if (!novelaActiva || !confirm('¿Eliminar este lugar del mundo?')) return;
    setState((prev) => ({
      ...prev,
      novelas: prev.novelas.map((n) => {
        if (n.id !== prev.novelaActivaId) return n;
        return {
          ...n,
          lugares: (n.lugares || []).filter((l) => l.id !== lId)
        };
      })
    }));
    showToast('Lugar eliminado');
  };

  // Export / Import
  const exportarJSON = () => {
    const jsonStr = JSON.stringify(state, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `biblia_escritura_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('📤 Copia de seguridad exportada');
  };

  const descargarZipProyecto = async () => {
    try {
      showToast('📦 Preparando descarga directa de archivo .ZIP...');
      const response = await fetch('/biblia-de-escritura-github-apk.zip');
      if (!response.ok) {
        throw new Error(`Error en descarga: ${response.statusText}`);
      }
      const buffer = await response.arrayBuffer();
      // Ensure strict binary application/zip MIME type
      const blob = new Blob([buffer], { type: 'application/zip' });
      const blobUrl = URL.createObjectURL(blob);

      const link = document.createElement('a');
      link.href = blobUrl;
      link.setAttribute('download', 'biblia-de-escritura-github-apk.zip');
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();

      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
      }, 2000);

      showToast('✅ Descargando archivo .ZIP listo para GitHub');
    } catch (err) {
      console.error('Error al descargar ZIP:', err);
      // Fallback si fetch fallara
      const fallbackLink = document.createElement('a');
      fallbackLink.href = '/biblia-de-escritura-github-apk.zip';
      fallbackLink.download = 'biblia-de-escritura-github-apk.zip';
      fallbackLink.target = '_blank';
      fallbackLink.click();
    }
  };

  const exportarMarkdownLibro = () => {
    if (!novelaActiva) return;
    const n = novelaActiva;
    let md = `# ${n.nombre}\n\n`;
    if (n.genero) md += `**Género:** ${n.genero}\n\n`;
    if (n.sinopsis) md += `> ${n.sinopsis}\n\n`;
    md += `---\n\n## 👥 ELENCO DE PERSONAJES (${n.personajes.length})\n\n`;

    n.personajes.forEach((p, idx) => {
      md += `### ${idx + 1}. ${p.nombre} ${p.rol ? `(${p.rol})` : ''}\n`;
      if (p.edad) md += `- **Edad/Época:** ${p.edad}\n`;
      if (p.origen) md += `- **Origen/Lugar:** ${p.origen}\n`;
      if (p.ocupacion) md += `- **Ocupación:** ${p.ocupacion}\n`;
      if (p.aliados) md += `- **Aliados:** ${p.aliados}\n`;
      if (p.caracteristicas) md += `- **Características:**\n  ${p.caracteristicas}\n`;
      if (p.historia) md += `- **Historia/Trasfondo:**\n  ${p.historia}\n`;
      if (p.notas) md += `- **Notas:**\n  ${p.notas}\n`;

      if (p.relaciones && p.relaciones.length > 0) {
        md += `- **Relaciones:**\n`;
        p.relaciones.forEach((r) => {
          const dest = n.personajes.find((x) => x.id === r.destinoId);
          md += `  - ${r.tipo} → **${dest ? dest.nombre : '(Eliminado)'}** ${r.notas ? `(${r.notas})` : ''}\n`;
        });
      }
      md += `\n`;
    });

    if (n.lugares && n.lugares.length > 0) {
      md += `---\n\n## 🏰 LUGARES Y MUNDO (${n.lugares.length})\n\n`;
      n.lugares.forEach((l) => {
        md += `### ${l.nombre} (${l.tipo})\n`;
        if (l.descripcion) md += `${l.descripcion}\n\n`;
        if (l.atmosfera) md += `*Atmósfera:* ${l.atmosfera}\n\n`;
      });
    }

    if (n.capitulos && n.capitulos.length > 0) {
      md += `---\n\n## 📜 CRONOLOGÍA Y CAPÍTULOS (${n.capitulos.length})\n\n`;
      n.capitulos.forEach((c) => {
        md += `### Cap. ${c.numero}: ${c.titulo} [${c.estado}]\n`;
        if (c.resumen) md += `${c.resumen}\n\n`;
      });
    }

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${n.nombre.replace(/\s+/g, '_')}_Biblia_Escritura.md`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('📑 Biblia descargada en formato Markdown');
  };

  const importarJSON = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target?.result as string);
        if (!parsed || !Array.isArray(parsed.novelas)) {
          throw new Error('El archivo no tiene el formato válido de Biblia de Escritura.');
        }
        if (!confirm('Esto reemplazará tus datos actuales. ¿Deseas continuar?')) return;

        setState({
          novelas: parsed.novelas,
          novelaActivaId: parsed.novelaActivaId || parsed.novelas[0]?.id || null,
          ultimoLibroId: parsed.ultimoLibroId || parsed.novelas[0]?.id || null,
          detallesAbiertos: parsed.detallesAbiertos || {},
          vistaActiva: 'home'
        });
        showToast('📥 Datos importados correctamente');
        setScreen('inicio');
      } catch (err: any) {
        showToast(`Error al importar: ${err.message}`, 'err');
      }
    };
    reader.readAsText(file);
  };

  // Filtered Characters
  const personajesFiltrados = useMemo(() => {
    if (!novelaActiva) return [];
    let list = novelaActiva.personajes;

    if (filtroRol !== 'todos') {
      list = list.filter((p) => p.rol?.toLowerCase().includes(filtroRol.toLowerCase()));
    }

    if (busqueda.trim()) {
      const q = busqueda.trim().toLowerCase();
      list = list.filter((p) => {
        const pool = [
          p.nombre,
          p.rol,
          p.origen,
          p.ocupacion,
          p.aliados,
          p.caracteristicas,
          p.historia,
          p.notas
        ]
          .join(' ')
          .toLowerCase();
        return pool.includes(q);
      });
    }

    return list;
  }, [novelaActiva, busqueda, filtroRol]);

  // Context Menu opener
  const handleOpenCtx = (e: React.MouseEvent, pId: string) => {
    e.stopPropagation();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    setCtxMenu({
      x: Math.min(rect.left, window.innerWidth - 230),
      y: Math.min(rect.bottom + 4, window.innerHeight - 200),
      pId
    });
  };

  // =========================================================
  // RENDER: LOGO SCREEN
  // =========================================================
  if (screen === 'logo') {
    return (
      <div
        onClick={() => {
          audioManager.resumeContext();
          if (!musicaMuted) {
            audioManager.playIntroTheme();
          }
          setScreen('inicio');
          setTimeout(() => {
            if (!musicaMuted) {
              audioManager.startBgm(pistaActual);
            }
          }, 1100);
        }}
        className="fixed inset-0 z-50 flex flex-col items-center justify-center px-6 py-12 sm:py-16 bg-splash-radial select-none overflow-y-auto cursor-pointer"
      >
        <div className="my-auto flex flex-col items-center max-w-sm w-full">
          <div className="relative mb-8">
            <div className="w-32 h-32 sm:w-36 sm:h-36 rounded-3xl bg-gradient-to-tr from-[#7c5cff]/30 to-[#ff7ac6]/30 flex items-center justify-center border border-[#7c5cff]/40 shadow-2xl animate-logo-pulse">
              <svg className="w-20 h-20 sm:w-22 sm:h-22 drop-shadow-lg" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 30 Q20 22 30 22 L50 22 L50 78 L30 78 Q20 78 20 70 Z" fill="url(#lg1)" opacity="0.9" />
                <path d="M80 30 Q80 22 70 22 L50 22 L50 78 L70 78 Q80 78 80 70 Z" fill="url(#lg2)" opacity="0.9" />
                <rect x="48.5" y="20" width="3" height="60" fill="#0f0f16" opacity="0.6" />
                <circle cx="50" cy="40" r="6" fill="#0f0f16" opacity="0.75" />
                <path d="M40 60 Q40 50 50 50 Q60 50 60 60 Z" fill="#0f0f16" opacity="0.75" />
                <circle cx="34" cy="34" r="1.8" fill="#fff" opacity="0.9" />
                <circle cx="66" cy="34" r="1.8" fill="#fff" opacity="0.9" />
                <circle cx="34" cy="48" r="1.3" fill="#fff" opacity="0.65" />
                <circle cx="66" cy="48" r="1.3" fill="#fff" opacity="0.65" />
                <defs>
                  <linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#7c5cff" />
                    <stop offset="100%" stopColor="#ff7ac6" />
                  </linearGradient>
                  <linearGradient id="lg2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#ff7ac6" />
                    <stop offset="100%" stopColor="#7c5cff" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-wider text-center bg-gradient-to-r from-[#7c5cff] via-[#c084fc] to-[#ff7ac6] bg-clip-text text-transparent font-['Cinzel'] drop-shadow">
            BIBLIA DE ESCRITURA
          </h1>
          <p className="mt-3 text-xs tracking-[3px] text-[#9a9ab0] uppercase font-semibold text-center">
            Tu elenco y universo narrativo siempre a mano
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-3 mt-8">
            <button
              onClick={(e) => {
                e.stopPropagation();
                audioManager.resumeContext();
                if (!musicaMuted) {
                  audioManager.playIntroTheme();
                }
                setScreen('inicio');
                setTimeout(() => {
                  if (!musicaMuted) {
                    audioManager.startBgm(pistaActual);
                  }
                }, 1100);
              }}
              className="px-8 py-3.5 rounded-full text-xs sm:text-sm font-bold bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] hover:brightness-110 text-white transition cursor-pointer shadow-xl hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" /> Iniciar espacio creativo →
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                const next = !musicaMuted;
                setMusicaMuted(next);
                audioManager.setMusicMuted(next);
                if (!next) {
                  audioManager.resumeContext();
                  audioManager.playIntroTheme();
                }
              }}
              className="px-4 py-2.5 rounded-full text-xs font-semibold bg-[#252533]/90 hover:bg-[#2e2e40] text-[#9a9ab0] hover:text-white border border-[#3a3a52] transition flex items-center gap-2 cursor-pointer shadow"
            >
              {musicaMuted ? (
                <VolumeX className="w-3.5 h-3.5 text-[#ff5566]" />
              ) : (
                <Volume2 className="w-3.5 h-3.5 text-[#4ade80]" />
              )}
              <span>{musicaMuted ? 'Música silenciada' : 'Música activada'}</span>
            </button>
          </div>

          <div className="mt-4 text-[11px] text-[#9a9ab0]/75 tracking-wider animate-pulse text-center">
            Toca cualquier parte para comenzar
          </div>
        </div>
      </div>
    );
  }

  // =========================================================
  // RENDER: SPLASH SCREEN
  // =========================================================
  if (screen === 'splash') {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center px-6 py-12 sm:py-16 bg-[#1a1a24] select-none overflow-y-auto">
        <div className="my-auto flex flex-col items-center max-w-sm w-full">
          <div className="w-22 h-22 mb-7 flex items-center justify-center rounded-3xl bg-gradient-to-tr from-[#7c5cff]/20 to-[#ff7ac6]/20 border border-[#7c5cff]/30 shadow-xl">
            <BookOpen className="w-11 h-11 text-[#ff7ac6] animate-pulse" />
          </div>

          <h2 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] bg-clip-text text-transparent tracking-wide text-center">
            Preparando tu Biblia de Escritura...
          </h2>

          <div className="w-full mt-9 space-y-3.5">
            <div className="h-2.5 w-full bg-[#2a2a3d] rounded-full overflow-hidden shadow-inner">
              <div
                className="h-full bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] rounded-full transition-all duration-300 ease-out shadow-[0_0_12px_rgba(124,92,255,0.7)]"
                style={{ width: `${splashPct}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-xs text-[#9a9ab0] px-1">
              <span className="font-medium">{splashMsg}</span>
              <span className="font-mono text-[#7c5cff] font-bold">{splashPct}%</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================
  // RENDER: PANTALLA DE INICIO (LAUNCHER)
  // =========================================================
  if (screen === 'inicio') {
    const ultimoLibro = state.novelas.find((n) => n.id === state.ultimoLibroId) || state.novelas[0] || null;

    return (
      <div className="fixed inset-0 z-40 flex flex-col items-center px-4 py-8 sm:py-14 bg-writing-radial overflow-y-auto">
        {/* TOP LAUNCHER BAR */}
        <div className="w-full max-w-xl flex items-center justify-between pt-2 pb-2 px-1">
          <div className="flex items-center gap-2 text-xs text-[#9a9ab0]">
            <span className="w-2 h-2 rounded-full bg-[#4ade80] animate-pulse" />
            <span className="font-medium">Espacio de escritura</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const next = !musicaMuted;
                setMusicaMuted(next);
                audioManager.setMusicMuted(next);
                if (!next) {
                  audioManager.resumeContext();
                  if (!audioManager.isBgmPlaying) audioManager.startBgm(pistaActual);
                }
                showToast(next ? '🔇 Música silenciada' : '🎵 Música activada');
              }}
              title={musicaMuted ? 'Música silenciada (clic para activar)' : 'Música sonando (clic para silenciar)'}
              className="px-3 py-1.5 rounded-full bg-[#252533] hover:bg-[#2e2e40] border border-[#3a3a52] text-[#9a9ab0] hover:text-white transition cursor-pointer flex items-center gap-2 text-xs font-semibold shadow"
            >
              {musicaMuted ? (
                <VolumeX className="w-3.5 h-3.5 text-[#ff5566]" />
              ) : (
                <Volume2 className="w-3.5 h-3.5 text-[#4ade80]" />
              )}
              <span>{musicaMuted ? 'Música silenciada' : 'Música activa'}</span>
            </button>
          </div>
        </div>

        <div className="w-full max-w-xl flex flex-col items-center my-auto pt-2 sm:pt-4 pb-12">
          <div className="text-center mb-8 sm:mb-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#7c5cff]/15 border border-[#7c5cff]/30 text-xs text-[#ff7ac6] font-semibold mb-3.5 shadow-sm">
              <Sparkles className="w-3.5 h-3.5" /> Estudio de creación literaria
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              📚 Biblia de <span className="bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] bg-clip-text text-transparent">Escritura</span>
            </h1>
            <p className="mt-2.5 text-xs sm:text-sm text-[#9a9ab0] max-w-md mx-auto">
              Elige con qué libro o universo quieres trabajar hoy
            </p>
          </div>

          <div className="w-full space-y-4">
            {/* CONTINUAR */}
            <button
              onClick={() => {
                if (ultimoLibro) abrirLibro(ultimoLibro.id);
                else setModalNuevoLibro(true);
              }}
              className="w-full p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#7c5cff]/20 to-[#ff7ac6]/15 hover:from-[#7c5cff]/30 hover:to-[#ff7ac6]/25 border border-[#7c5cff]/40 hover:border-[#ff7ac6]/60 transition-all shadow-lg hover:shadow-2xl hover:-translate-y-0.5 text-left flex items-center gap-4 cursor-pointer group"
            >
              <div
                className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 shadow-md group-hover:scale-105 transition-transform"
                style={{ background: ultimoLibro ? `linear-gradient(135deg, ${ultimoLibro.color}, #ff7ac6)` : 'linear-gradient(135deg, #7c5cff, #ff7ac6)' }}
              >
                📖
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-bold text-[#c084fc] uppercase tracking-wider mb-0.5">Continuar con</div>
                <div className="text-base sm:text-lg font-bold text-white truncate">
                  {ultimoLibro ? `"${ultimoLibro.nombre}"` : 'Crear tu primer libro'}
                </div>
                <div className="text-xs text-[#9a9ab0] truncate mt-0.5">
                  {ultimoLibro ? `${ultimoLibro.personajes.length} personaje(s) registrados · ${ultimoLibro.genero || 'Novela'}` : 'Empieza tu primera obra literaria'}
                </div>
              </div>
              <ArrowRight className="w-5 h-5 text-[#9a9ab0] group-hover:text-[#ff7ac6] group-hover:translate-x-1 transition-all flex-shrink-0" />
            </button>

            {/* NUEVO LIBRO */}
            <button
              onClick={() => setModalNuevoLibro(true)}
              className="w-full p-4 sm:p-5 rounded-2xl bg-[#252533] hover:bg-[#2e2e40] border border-[#3a3a52] hover:border-[#7c5cff]/60 transition-all shadow-md hover:-translate-y-0.5 text-left flex items-center gap-4 cursor-pointer group"
            >
              <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-[#2e2e40] border border-[#3a3a52] flex items-center justify-center text-2xl flex-shrink-0 group-hover:border-[#7c5cff]/50">
                ➕
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-base font-bold text-white">Escribir nuevo libro</div>
                <div className="text-xs text-[#9a9ab0] mt-0.5">Crea una nueva novela, saga o historia desde cero</div>
              </div>
              <ArrowRight className="w-5 h-5 text-[#9a9ab0] group-hover:text-white group-hover:translate-x-1 transition-all flex-shrink-0" />
            </button>

            {/* EDITAR OTRO LIBRO / BIBLIOTECA */}
            <button
              onClick={() => setModalRegistroLibros(true)}
              className="w-full p-4 sm:p-5 rounded-2xl bg-[#252533] hover:bg-[#2e2e40] border border-[#3a3a52] hover:border-[#7c5cff]/60 transition-all shadow-md hover:-translate-y-0.5 text-left flex items-center gap-4 cursor-pointer group"
            >
              <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-[#2e2e40] border border-[#3a3a52] flex items-center justify-center text-2xl flex-shrink-0 group-hover:border-[#7c5cff]/50">
                🗂️
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-base font-bold text-white">Mis libros ({state.novelas.length})</div>
                <div className="text-xs text-[#9a9ab0] mt-0.5">Explora, renombra y administra toda tu biblioteca</div>
              </div>
              <ArrowRight className="w-5 h-5 text-[#9a9ab0] group-hover:text-white group-hover:translate-x-1 transition-all flex-shrink-0" />
            </button>
          </div>

          <div className="mt-9 flex items-center gap-5 text-xs text-[#9a9ab0]">
            <button
              onClick={exportarJSON}
              className="inline-flex items-center gap-1.5 hover:text-white cursor-pointer transition font-medium"
            >
              <Download className="w-3.5 h-3.5" /> Copia de seguridad
            </button>
            <span className="text-[#3a3a52]">•</span>
            <label className="inline-flex items-center gap-1.5 hover:text-white cursor-pointer transition font-medium">
              <Upload className="w-3.5 h-3.5" /> Importar archivo
              <input
                type="file"
                accept=".json"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && importarJSON(e.target.files[0])}
              />
            </label>
            <span className="text-[#3a3a52]">•</span>
            <button
              onClick={descargarZipProyecto}
              className="inline-flex items-center gap-1.5 hover:text-white cursor-pointer transition font-medium text-[#38bdf8]"
            >
              <Download className="w-3.5 h-3.5" /> ZIP para APK
            </button>
          </div>
        </div>

        {/* MODAL: NUEVO LIBRO */}
        {modalNuevoLibro && (
          <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[#252533] border border-[#3a3a52] rounded-2xl p-6 shadow-2xl animate-modal-in">
              <div className="flex items-center justify-between pb-3 border-b border-[#3a3a52] mb-4">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <span>➕</span> Nuevo libro
                </h3>
                <button
                  onClick={() => setModalNuevoLibro(false)}
                  className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.currentTarget;
                  const nombre = (form.elements.namedItem('libro_nombre') as HTMLInputElement).value;
                  const genero = (form.elements.namedItem('libro_genero') as HTMLInputElement).value;
                  const sinopsis = (form.elements.namedItem('libro_sinopsis') as HTMLTextAreaElement).value;
                  crearNuevoLibro(nombre, genero, sinopsis);
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#9a9ab0] mb-1 font-semibold">
                    Título del libro *
                  </label>
                  <input
                    name="libro_nombre"
                    type="text"
                    required
                    placeholder="Ej: El Susurro de las Estrellas"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#9a9ab0] mb-1 font-semibold">
                    Género literario
                  </label>
                  <input
                    name="libro_genero"
                    type="text"
                    placeholder="Ej: Fantasía Épica, Thriller Psicológico, Romance Histórico..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#9a9ab0] mb-1 font-semibold">
                    Premisa o Sinopsis corta
                  </label>
                  <textarea
                    name="libro_sinopsis"
                    rows={3}
                    placeholder="¿De qué trata este libro? ¿Cuál es el conflicto central?"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff] resize-none"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setModalNuevoLibro(false)}
                    className="px-4 py-2 rounded-xl text-sm font-semibold bg-transparent border border-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-sm font-semibold bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] text-white hover:brightness-110 cursor-pointer shadow-md"
                  >
                    Crear y abrir libro
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL: REGISTRO DE LIBROS */}
        {modalRegistroLibros && (
          <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
            <div className="w-full max-w-lg bg-[#252533] border border-[#3a3a52] rounded-2xl p-6 shadow-2xl animate-modal-in max-h-[85vh] flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-[#3a3a52] mb-4 flex-shrink-0">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <span>🗂️</span> Tus Libros ({state.novelas.length})
                </h3>
                <button
                  onClick={() => setModalRegistroLibros(false)}
                  className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                {state.novelas.length === 0 ? (
                  <div className="text-center py-10 text-[#9a9ab0] text-sm">
                    No tienes libros creados aún.
                  </div>
                ) : (
                  state.novelas.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => {
                        setModalRegistroLibros(false);
                        abrirLibro(n.id);
                      }}
                      className="p-3.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] hover:border-[#7c5cff] transition flex items-center gap-3.5 cursor-pointer group"
                    >
                      <div
                        className="w-4 h-4 rounded-full flex-shrink-0"
                        style={{ backgroundColor: n.color }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-white text-sm truncate group-hover:text-[#ff7ac6] transition-colors">
                          {n.nombre}
                        </div>
                        <div className="text-xs text-[#9a9ab0] flex items-center gap-2">
                          <span>{n.personajes.length} personajes</span>
                          <span>•</span>
                          <span>{n.capitulos?.length || 0} capítulos</span>
                          {n.id === state.ultimoLibroId && (
                            <span className="text-[#c084fc] font-semibold text-[10px] uppercase">
                              (Último abierto)
                            </span>
                          )}
                        </div>
                      </div>
                      <div
                        className="flex items-center gap-1.5 flex-shrink-0"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => renombrarLibro(n.id)}
                          title="Renombrar"
                          className="p-1.5 rounded-lg bg-[#252533] hover:bg-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => borrarLibro(n.id)}
                          title="Eliminar"
                          className="p-1.5 rounded-lg bg-[#252533] hover:bg-[#ff5566]/20 text-[#9a9ab0] hover:text-[#ff5566] cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="pt-4 border-t border-[#3a3a52] mt-4 flex items-center justify-between flex-shrink-0">
                <button
                  onClick={() => {
                    setModalRegistroLibros(false);
                    setModalNuevoLibro(true);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[#7c5cff]/20 text-[#c084fc] border border-[#7c5cff]/40 hover:bg-[#7c5cff]/30 cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" /> Nuevo libro
                </button>
                <button
                  onClick={() => setModalRegistroLibros(false)}
                  className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-transparent border border-[#3a3a52] text-[#e8e8f0] hover:border-white cursor-pointer"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // =========================================================
  // RENDER: APP PRINCIPAL
  // =========================================================
  return (
    <div className="flex flex-col h-[100dvh] w-full bg-[#1a1a24] text-[#e8e8f0] overflow-hidden select-none">
      {/* HEADER */}
      <header className="min-h-16 sm:min-h-18 px-4 sm:px-6 bg-gradient-to-r from-[#241a3d] via-[#1f1f33] to-[#1c233c] border-b border-[#3a3a52] flex items-center justify-between gap-3 flex-shrink-0 z-30 shadow-md pt-[env(safe-area-inset-top,0px)]">
        <div className="flex items-center gap-3 min-w-0 py-1">
          <button
            onClick={() => setScreen('inicio')}
            title="Ir al inicio"
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div
              className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm"
              style={{ background: novelaActiva ? `linear-gradient(135deg, ${novelaActiva.color}, #ff7ac6)` : 'linear-gradient(135deg, #7c5cff, #ff7ac6)' }}
            >
              <Feather className="w-4.5 h-4.5 text-white" />
            </div>
            <h1 className="text-sm sm:text-base font-extrabold tracking-wide hidden xs:inline truncate">
              Biblia de <span className="text-[#ff7ac6]">Escritura</span>
            </h1>
          </button>
        </div>

        {/* LIBRO ACTIVO PILL */}
        <div className="flex items-center gap-2.5">
          {novelaActiva && (
            <button
              onClick={() => setModalRegistroLibros(true)}
              className="px-3.5 py-1.5 rounded-full text-xs font-bold border transition flex items-center gap-2 max-w-[160px] sm:max-w-[220px] truncate cursor-pointer shadow-sm hover:brightness-125"
              style={{
                borderColor: novelaActiva.color,
                backgroundColor: `${novelaActiva.color}22`,
                color: '#ffffff'
              }}
              title="Clic para cambiar de libro"
            >
              <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: novelaActiva.color }} />
              <span className="truncate">{novelaActiva.nombre}</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60 flex-shrink-0" />
            </button>
          )}

          {/* BOTÓN RÁPIDO SILENCIAR / ACTIVAR MÚSICA */}
          <button
            onClick={() => {
              const next = !musicaMuted;
              setMusicaMuted(next);
              audioManager.setMusicMuted(next);
              if (!next) {
                audioManager.resumeContext();
                if (!audioManager.isBgmPlaying) audioManager.startBgm(pistaActual);
              }
              showToast(next ? '🔇 Música silenciada' : '🎵 Música activada');
            }}
            title={musicaMuted ? 'Música silenciada (clic para activar)' : 'Música sonando (clic para silenciar)'}
            className="p-2 rounded-xl bg-[#2e2e40] hover:bg-[#3a3a52] text-[#9a9ab0] hover:text-[#ff7ac6] border border-[#3a3a52] transition cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
          >
            {musicaMuted ? (
              <VolumeX className="w-4 h-4 text-[#ff5566]" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#4ade80]" />
            )}
          </button>

          <button
            onClick={exportarMarkdownLibro}
            title="Descargar Ficha Completa en Markdown"
            className="p-2 rounded-xl bg-[#2e2e40] hover:bg-[#3a3a52] text-[#9a9ab0] hover:text-[#ff7ac6] border border-[#3a3a52] transition cursor-pointer hidden sm:flex items-center gap-1.5 text-xs font-semibold"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Ficha .md</span>
          </button>
        </div>
      </header>

      {/* CONTENEDOR DE VISTAS */}
      <main className="flex-1 overflow-hidden relative flex flex-col pb-[74px] sm:pb-[78px]">
        {/* =========================================================
            VISTA: HOME / PERSONAJES
            ========================================================= */}
        {state.vistaActiva === 'home' && (
          <div className="flex-1 flex flex-col overflow-hidden animate-fade-in">
            {/* TOOLBAR */}
            <div className="px-4 py-3.5 sm:px-6 sm:py-4 bg-[#252533] border-b border-[#3a3a52] flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4 flex-shrink-0 shadow-sm">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#9a9ab0] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                  placeholder="Buscar personaje por nombre, rol, origen, historia..."
                  className="w-full pl-10 pr-9 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-xs sm:text-sm text-white placeholder-[#9a9ab0] focus:outline-none focus:border-[#7c5cff]"
                />
                {busqueda && (
                  <button
                    onClick={() => setBusqueda('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#9a9ab0] hover:text-white p-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* FILTROS ROL & CONTADOR */}
              <div className="flex items-center justify-between sm:justify-end gap-2.5 overflow-x-auto no-scrollbar">
                <div className="flex items-center gap-1.5 text-xs">
                  {['todos', 'protagonista', 'antagonista', 'secundario'].map((rol) => (
                    <button
                      key={rol}
                      onClick={() => setFiltroRol(rol)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition cursor-pointer ${
                        filtroRol === rol
                          ? 'bg-[#7c5cff] text-white shadow-sm'
                          : 'bg-[#2e2e40] text-[#9a9ab0] hover:text-white border border-[#3a3a52]'
                      }`}
                    >
                      {rol}
                    </button>
                  ))}
                </div>

                <div className="px-3 py-1.5 rounded-lg bg-[#2e2e40] border border-[#3a3a52] text-xs font-mono text-[#c084fc] font-bold whitespace-nowrap flex items-center gap-1.5 flex-shrink-0">
                  <Users className="w-3.5 h-3.5 text-[#ff7ac6]" />
                  <span>{personajesFiltrados.length}</span>
                  {busqueda && <span className="text-[10px] text-[#9a9ab0]">/{novelaActiva?.personajes.length || 0}</span>}
                </div>
              </div>
            </div>

            {/* LISTA DE PERSONAJES */}
            <div className="flex-1 overflow-y-auto px-4 py-5 sm:px-6 sm:py-6">
              <div className="max-w-4xl mx-auto space-y-4 sm:space-y-5 pb-24 sm:pb-28">
                {personajesFiltrados.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center text-[#9a9ab0] px-4">
                    <div className="text-4xl mb-3">
                      {busqueda ? '🔍' : '👥'}
                    </div>
                    <div className="text-base font-semibold text-white">
                      {busqueda ? 'Sin coincidencias para la búsqueda' : 'Aún no tienes personajes en este libro'}
                    </div>
                    <p className="text-xs text-[#9a9ab0] max-w-sm mt-1">
                      {busqueda
                        ? 'Prueba con otros términos de búsqueda o borra el filtro.'
                        : 'Comienza a dar vida a tu elenco pulsando el botón + abajo a la derecha.'}
                    </p>
                    {!busqueda && (
                      <button
                        onClick={() => setModalNuevoPersonaje(true)}
                        className="mt-4 px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] text-white hover:brightness-110 cursor-pointer shadow-md flex items-center gap-2"
                      >
                        <Plus className="w-4 h-4" /> Crear primer personaje
                      </button>
                    )}
                  </div>
                ) : (
                  personajesFiltrados.map((p) => {
                    const abierto = !!state.detallesAbiertos[p.id];
                    const rels = p.relaciones || [];

                    return (
                      <div
                        key={p.id}
                        className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-4 transition-all hover:border-[#4a4a68] shadow-md relative"
                        style={{ borderLeftWidth: '5px', borderLeftColor: novelaActiva?.color || '#7c5cff' }}
                      >
                        {/* CABECERA DE LA TARJETA */}
                        <div className="flex items-center gap-3.5">
                          <div
                            className="w-11 h-11 rounded-full flex items-center justify-center font-black text-white text-base shadow-inner flex-shrink-0"
                            style={{
                              background: `linear-gradient(135deg, ${novelaActiva?.color || '#7c5cff'}, #ff7ac6)`
                            }}
                          >
                            {iniciales(p.nombre)}
                          </div>

                          <div className="flex-1 min-w-0">
                            <h3 className="text-base sm:text-lg font-bold text-white tracking-wide truncate">
                              {p.nombre}
                            </h3>
                            <div className="text-xs font-semibold text-[#ff7ac6] truncate">
                              {p.rol || <span className="text-[#646482] font-normal italic">Sin rol asignado</span>}
                            </div>
                          </div>

                          {/* BOTON CONTEXTUAL ⋯ */}
                          <button
                            onClick={(e) => handleOpenCtx(e, p.id)}
                            title="Opciones"
                            className="p-2 rounded-xl bg-[#2e2e40] hover:bg-[#3a3a52] text-[#9a9ab0] hover:text-white transition cursor-pointer flex-shrink-0"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>

                        {/* TOGGLE DETALLES */}
                        <button
                          onClick={() => toggleDetallePersonaje(p.id)}
                          className={`w-full mt-3.5 py-2 px-3 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-semibold text-[#e8e8f0] flex items-center justify-center gap-2 transition cursor-pointer ${
                            abierto ? 'border-[#7c5cff]/50 text-white' : ''
                          }`}
                        >
                          <span>{abierto ? 'Ocultar detalles' : 'Ver más detalles de la ficha'}</span>
                          <ChevronDown
                            className={`w-3.5 h-3.5 transition-transform duration-200 ${abierto ? 'rotate-180 text-[#ff7ac6]' : ''}`}
                          />
                        </button>

                        {/* PANEL DE DETALLES ACCORDION */}
                        {abierto && (
                          <div className="mt-3.5 pt-3 border-t border-dashed border-[#3a3a52] space-y-3 animate-fade-in text-xs sm:text-sm">
                            {/* Grid 2 columnas */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              {p.edad && (
                                <div className="p-2.5 rounded-xl bg-[#2e2e40]/70 border border-[#3a3a52]/60">
                                  <div className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5 mb-1">
                                    <Cake className="w-3 h-3 text-[#ff7ac6]" /> Edad / Época
                                  </div>
                                  <div className="text-white font-medium">{p.edad}</div>
                                </div>
                              )}

                              {p.origen && (
                                <div className="p-2.5 rounded-xl bg-[#2e2e40]/70 border border-[#3a3a52]/60">
                                  <div className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5 mb-1">
                                    <MapPin className="w-3 h-3 text-[#38bdf8]" /> Origen / Lugar
                                  </div>
                                  <div className="text-white font-medium">{p.origen}</div>
                                </div>
                              )}

                              {p.ocupacion && (
                                <div className="p-2.5 rounded-xl bg-[#2e2e40]/70 border border-[#3a3a52]/60">
                                  <div className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5 mb-1">
                                    <Briefcase className="w-3 h-3 text-[#facc15]" /> Ocupación / Oficio
                                  </div>
                                  <div className="text-white font-medium">{p.ocupacion}</div>
                                </div>
                              )}

                              {p.aliados && (
                                <div className="p-2.5 rounded-xl bg-[#2e2e40]/70 border border-[#3a3a52]/60">
                                  <div className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5 mb-1">
                                    <Shield className="w-3 h-3 text-[#4ade80]" /> Aliados / Red
                                  </div>
                                  <div className="text-white font-medium">{p.aliados}</div>
                                </div>
                              )}
                            </div>

                            {/* Full text fields */}
                            {p.caracteristicas && (
                              <div className="p-2.5 rounded-xl bg-[#2e2e40]/70 border border-[#3a3a52]/60">
                                <div className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5 mb-1">
                                  <Sparkles className="w-3 h-3 text-[#a78bfa]" /> Características Físicas y Psicológicas
                                </div>
                                <div className="text-white font-normal whitespace-pre-line leading-relaxed">
                                  {p.caracteristicas}
                                </div>
                              </div>
                            )}

                            {p.historia && (
                              <div className="p-2.5 rounded-xl bg-[#2e2e40]/70 border border-[#3a3a52]/60">
                                <div className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5 mb-1">
                                  <BookOpen className="w-3 h-3 text-[#ff7ac6]" /> Historia / Trasfondo
                                </div>
                                <div className="text-white font-normal whitespace-pre-line leading-relaxed">
                                  {p.historia}
                                </div>
                              </div>
                            )}

                            {p.notas && (
                              <div className="p-2.5 rounded-xl bg-[#2e2e40]/70 border border-[#3a3a52]/60">
                                <div className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5 mb-1">
                                  <FileText className="w-3 h-3 text-[#fb923c]" /> Notas personales y secretos
                                </div>
                                <div className="text-white font-normal whitespace-pre-line leading-relaxed">
                                  {p.notas}
                                </div>
                              </div>
                            )}

                            {/* RELACIONES CHIPS */}
                            <div className="pt-2">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-[10px] uppercase font-bold text-[#9a9ab0] flex items-center gap-1.5">
                                  <GitFork className="w-3 h-3 text-[#7c5cff]" /> Vínculos & Relaciones ({rels.length})
                                </span>
                                <button
                                  onClick={() => setModalRelaciones(p)}
                                  className="text-[11px] text-[#c084fc] hover:underline font-semibold cursor-pointer"
                                >
                                  + Gestionar relaciones
                                </button>
                              </div>

                              {rels.length === 0 ? (
                                <div className="text-xs text-[#646482] italic">
                                  Sin relaciones registradas aún.
                                </div>
                              ) : (
                                <div className="flex flex-wrap gap-2">
                                  {rels.map((r) => {
                                    const dest = novelaActiva?.personajes.find((x) => x.id === r.destinoId);
                                    return (
                                      <div
                                        key={r.id}
                                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#2e2e40] border border-[#3a3a52] text-xs shadow-sm"
                                      >
                                        <span className="text-[#ff7ac6] font-bold text-[10px] uppercase">
                                          {r.tipo}
                                        </span>
                                        <span className="text-[#9a9ab0]">→</span>
                                        <span className="font-bold text-white">
                                          {dest ? dest.nombre : '(Eliminado)'}
                                        </span>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* FAB BOTON CREAR (SOLO HOME) */}
            <button
              onClick={() => setModalNuevoPersonaje(true)}
              title="Crear personaje (Ctrl + N)"
              className="fixed right-5 sm:right-7 bottom-24 sm:bottom-26 w-14 h-14 sm:w-15 sm:h-15 rounded-full bg-gradient-to-tr from-[#7c5cff] to-[#ff7ac6] text-white flex items-center justify-center text-2xl shadow-[0_8px_25px_rgba(124,92,255,0.6)] hover:scale-105 active:scale-95 transition-all z-40 cursor-pointer"
            >
              <Plus className="w-7 h-7" />
            </button>
          </div>
        )}

        {/* =========================================================
            VISTA: CONEXIONES
            ========================================================= */}
        {state.vistaActiva === 'conexiones' && (
          <div className="flex-1 flex flex-col overflow-hidden animate-fade-in">
            <div className="px-4 py-3.5 sm:px-6 sm:py-4 bg-[#252533] border-b border-[#3a3a52] flex items-center justify-between gap-3 flex-shrink-0 shadow-sm">
              <div className="text-xs sm:text-sm font-semibold text-[#e8e8f0] flex items-center gap-2">
                <GitFork className="w-4 h-4 text-[#ff7ac6]" />
                <span>
                  Mapa de relaciones de <b style={{ color: novelaActiva?.color }}>{novelaActiva?.nombre}</b>
                </span>
              </div>
              {novelaActiva && novelaActiva.personajes.length >= 2 && (
                <button
                  onClick={() => setModalRelaciones(novelaActiva.personajes[0])}
                  className="px-3.5 py-1.5 rounded-xl bg-[#7c5cff] hover:bg-[#6b4dec] text-white text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" /> Nueva relación
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-5 sm:px-6 sm:py-6">
              <div className="max-w-4xl mx-auto space-y-4 sm:space-y-5 pb-24 sm:pb-28">
                {(() => {
                  if (!novelaActiva) return null;
                  const conRels = novelaActiva.personajes
                    .map((p) => ({
                      personaje: p,
                      rels: (p.relaciones || []).filter((r) =>
                        novelaActiva.personajes.some((x) => x.id === r.destinoId)
                      )
                    }))
                    .filter((x) => x.rels.length > 0);

                  const totalRels = conRels.reduce((acc, curr) => acc + curr.rels.length, 0);

                  if (totalRels === 0) {
                    return (
                      <div className="flex flex-col items-center justify-center py-20 text-center text-[#9a9ab0] px-4">
                        <GitFork className="w-12 h-12 text-[#7c5cff]/60 mb-3" />
                        <div className="text-lg font-bold text-white">
                          Aún no hay conexiones entre personajes
                        </div>
                        <p className="text-xs text-[#9a9ab0] max-w-sm mt-1">
                          Las conexiones narrativas (alianzas, rivalidades, lazos de sangre, romances) darán coherencia a tu trama.
                        </p>
                        {novelaActiva.personajes.length >= 2 ? (
                          <button
                            onClick={() => setModalRelaciones(novelaActiva.personajes[0])}
                            className="mt-4 px-4 py-2 rounded-xl text-xs font-bold bg-[#7c5cff] text-white hover:bg-[#6b4dec] cursor-pointer"
                          >
                            + Conectar personajes ahora
                          </button>
                        ) : (
                          <p className="text-[11px] text-[#ff7ac6] mt-3">
                            Necesitas al menos 2 personajes en el libro para enlazarlos.
                          </p>
                        )}
                      </div>
                    );
                  }

                  return (
                    <>
                      <div className="text-xs uppercase tracking-wider text-[#9a9ab0] font-semibold flex items-center gap-2">
                        <span>{totalRels} conexión(es) activas</span>
                        <span>•</span>
                        <span>{conRels.length} personajes vinculados</span>
                      </div>

                      {conRels.map(({ personaje, rels }) => (
                        <div
                          key={personaje.id}
                          className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-4 sm:p-5 shadow-md space-y-3"
                        >
                          <div className="flex items-center justify-between pb-2.5 border-b border-[#3a3a52]">
                            <div className="flex items-center gap-2.5">
                              <div
                                className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white"
                                style={{ background: `linear-gradient(135deg, ${novelaActiva.color}, #ff7ac6)` }}
                              >
                                {iniciales(personaje.nombre)}
                              </div>
                              <div>
                                <h4 className="font-bold text-white text-sm">{personaje.nombre}</h4>
                                <span className="text-[11px] text-[#9a9ab0]">{personaje.rol || 'Sin rol'}</span>
                              </div>
                            </div>
                            <button
                              onClick={() => setModalRelaciones(personaje)}
                              className="text-xs text-[#c084fc] hover:underline font-semibold cursor-pointer"
                            >
                              Editar vínculos
                            </button>
                          </div>

                          <div className="space-y-2">
                            {rels.map((r) => {
                              const dest = novelaActiva.personajes.find((x) => x.id === r.destinoId);
                              return (
                                <div
                                  key={r.id}
                                  className="p-3 rounded-xl bg-[#2e2e40] border border-[#3a3a52]/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                                >
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="px-2 py-0.5 rounded-md bg-[#ff7ac6]/15 border border-[#ff7ac6]/30 text-[#ff7ac6] font-bold text-[10px] uppercase tracking-wider">
                                      {r.tipo}
                                    </span>
                                    <span className="text-[#9a9ab0]">hacia</span>
                                    <span className="font-bold text-white text-sm">
                                      {dest ? dest.nombre : '(Eliminado)'}
                                    </span>
                                  </div>
                                  {r.notas && (
                                    <div className="text-[#9a9ab0] italic text-xs bg-[#1a1a24]/50 px-2.5 py-1 rounded-lg">
                                      "{r.notas}"
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </>
                  );
                })()}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            VISTA: TRAMA & CAPÍTULOS
            ========================================================= */}
        {state.vistaActiva === 'trama' && (
          <div className="flex-1 flex flex-col overflow-hidden animate-fade-in">
            <div className="px-4 py-3.5 sm:px-6 sm:py-4 bg-[#252533] border-b border-[#3a3a52] flex items-center justify-between gap-3 flex-shrink-0 shadow-sm">
              <div className="text-xs sm:text-sm font-semibold text-[#e8e8f0] flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#7c5cff]" />
                <span>Estructura de Capítulos & Trama</span>
              </div>
              <button
                onClick={() => setModalNuevoCapitulo(true)}
                className="px-3.5 py-1.5 rounded-xl bg-[#7c5cff] hover:bg-[#6b4dec] text-white text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" /> Nuevo capítulo
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-5 sm:px-6 sm:py-6">
              <div className="max-w-4xl mx-auto space-y-4 sm:space-y-5 pb-24 sm:pb-28">
                {(!novelaActiva?.capitulos || novelaActiva.capitulos.length === 0) ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center text-[#9a9ab0] px-4">
                    <FileText className="w-12 h-12 text-[#7c5cff]/60 mb-3" />
                    <div className="text-lg font-bold text-white">Sin capítulos ni escenas registradas</div>
                    <p className="text-xs text-[#9a9ab0] max-w-sm mt-1">
                      Organiza el ritmo de tu historia capítulo a capítulo con resúmenes, personajes que intervienen y notas de ritmo.
                    </p>
                    <button
                      onClick={() => setModalNuevoCapitulo(true)}
                      className="mt-4 px-4 py-2 rounded-xl text-xs font-bold bg-[#7c5cff] text-white hover:bg-[#6b4dec] cursor-pointer"
                    >
                      + Añadir primer capítulo
                    </button>
                  </div>
                ) : (
                  novelaActiva.capitulos
                    .sort((a, b) => a.numero - b.numero)
                    .map((c) => {
                      const badgeColor =
                        c.estado === 'Finalizado'
                          ? 'bg-[#4ade80]/15 text-[#4ade80] border-[#4ade80]/30'
                          : c.estado === 'En revisión'
                          ? 'bg-[#facc15]/15 text-[#facc15] border-[#facc15]/30'
                          : 'bg-[#7c5cff]/15 text-[#c084fc] border-[#7c5cff]/30';

                      return (
                        <div
                          key={c.id}
                          className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-4 sm:p-5 shadow-md space-y-3 hover:border-[#4a4a68] transition"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs font-black text-[#ff7ac6] bg-[#2e2e40] px-2 py-0.5 rounded-md border border-[#3a3a52]">
                                  Cap. {c.numero}
                                </span>
                                <h3 className="font-bold text-white text-base">{c.titulo}</h3>
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badgeColor}`}>
                                  {c.estado}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-1.5 flex-shrink-0">
                              <button
                                onClick={() => setModalEditarCapitulo(c)}
                                className="p-1.5 rounded-lg bg-[#2e2e40] hover:bg-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => borrarCapitulo(c.id)}
                                className="p-1.5 rounded-lg bg-[#2e2e40] hover:bg-[#ff5566]/20 text-[#9a9ab0] hover:text-[#ff5566] cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {c.resumen && (
                            <p className="text-xs sm:text-sm text-[#e8e8f0] leading-relaxed whitespace-pre-line bg-[#2e2e40]/60 p-3 rounded-xl border border-[#3a3a52]/40">
                              {c.resumen}
                            </p>
                          )}

                          {c.personajesIds && c.personajesIds.length > 0 && (
                            <div className="flex items-center gap-1.5 flex-wrap pt-1">
                              <span className="text-[10px] uppercase font-bold text-[#9a9ab0]">Personajes:</span>
                              {c.personajesIds.map((pid) => {
                                const pers = novelaActiva.personajes.find((p) => p.id === pid);
                                return pers ? (
                                  <span
                                    key={pid}
                                    className="px-2.5 py-0.5 rounded-md bg-[#2e2e40] text-[11px] font-semibold text-white border border-[#3a3a52]"
                                  >
                                    {pers.nombre}
                                  </span>
                                ) : null;
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })
                )}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            VISTA: LUGARES & MUNDO
            ========================================================= */}
        {state.vistaActiva === 'lugares' && (
          <div className="flex-1 flex flex-col overflow-hidden animate-fade-in">
            <div className="px-4 py-3.5 sm:px-6 sm:py-4 bg-[#252533] border-b border-[#3a3a52] flex items-center justify-between gap-3 flex-shrink-0 shadow-sm">
              <div className="text-xs sm:text-sm font-semibold text-[#e8e8f0] flex items-center gap-2">
                <Compass className="w-4 h-4 text-[#38bdf8]" />
                <span>Geografía, Ciudades & Escenarios</span>
              </div>
              <button
                onClick={() => setModalNuevoLugar(true)}
                className="px-3.5 py-1.5 rounded-xl bg-[#7c5cff] hover:bg-[#6b4dec] text-white text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" /> Nuevo lugar
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-5 sm:px-6 sm:py-6">
              <div className="max-w-4xl mx-auto space-y-4 sm:space-y-5 pb-24 sm:pb-28">
                {(!novelaActiva?.lugares || novelaActiva.lugares.length === 0) ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center text-[#9a9ab0] px-4">
                    <MapPin className="w-12 h-12 text-[#38bdf8]/60 mb-3" />
                    <div className="text-lg font-bold text-white">Sin lugares registrados</div>
                    <p className="text-xs text-[#9a9ab0] max-w-sm mt-1">
                      Registra castillos, tabernas, reinos o planetas donde transcurre la trama para mantener coherencia en las descripciones.
                    </p>
                    <button
                      onClick={() => setModalNuevoLugar(true)}
                      className="mt-4 px-4 py-2 rounded-xl text-xs font-bold bg-[#7c5cff] text-white hover:bg-[#6b4dec] cursor-pointer"
                    >
                      + Registrar primer lugar
                    </button>
                  </div>
                ) : (
                  novelaActiva.lugares.map((l) => (
                    <div
                      key={l.id}
                      className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-4 sm:p-5 shadow-md space-y-3 hover:border-[#4a4a68] transition"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-white text-base flex items-center gap-1.5">
                              <MapPin className="w-4 h-4 text-[#38bdf8]" />
                              {l.nombre}
                            </h3>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#38bdf8]/15 text-[#38bdf8] border border-[#38bdf8]/30">
                              {l.tipo}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <button
                            onClick={() => setModalEditarLugar(l)}
                            className="p-1.5 rounded-lg bg-[#2e2e40] hover:bg-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => borrarLugar(l.id)}
                            className="p-1.5 rounded-lg bg-[#2e2e40] hover:bg-[#ff5566]/20 text-[#9a9ab0] hover:text-[#ff5566] cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {l.descripcion && (
                        <p className="text-xs sm:text-sm text-[#e8e8f0] leading-relaxed whitespace-pre-line bg-[#2e2e40]/60 p-3 rounded-xl border border-[#3a3a52]/40">
                          {l.descripcion}
                        </p>
                      )}

                      {l.atmosfera && (
                        <div className="text-xs text-[#9a9ab0] italic flex items-center gap-1.5">
                          <span className="font-bold text-[#c084fc] not-italic text-[10px] uppercase">Atmósfera:</span>
                          <span>{l.atmosfera}</span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            VISTA: CONFIGURACIÓN
            ========================================================= */}
        {state.vistaActiva === 'config' && (
          <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-6 sm:py-8 animate-fade-in">
            <div className="max-w-xl mx-auto space-y-5 sm:space-y-6 pb-24 sm:pb-28">
              {/* LIBRO ACTUAL */}
              <div className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-5 shadow-md">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#9a9ab0] mb-2 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-[#7c5cff]" /> Libro activo
                </h3>
                {novelaActiva ? (
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: novelaActiva.color }} />
                      <span className="text-lg font-bold text-white">{novelaActiva.nombre}</span>
                    </div>
                    <p className="text-xs text-[#9a9ab0] mb-4">
                      {novelaActiva.genero ? `${novelaActiva.genero} • ` : ''}
                      {novelaActiva.personajes.length} personaje(s) registrados.
                    </p>

                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setModalRegistroLibros(true)}
                        className="px-4 py-2 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-semibold text-white transition cursor-pointer flex items-center gap-2"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> Cambiar de libro
                      </button>
                      <button
                        onClick={() => renombrarLibro(novelaActiva.id)}
                        className="px-4 py-2 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-semibold text-white transition cursor-pointer flex items-center gap-2"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> Renombrar libro
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-[#9a9ab0]">Ningún libro activo.</p>
                )}
              </div>

              {/* SECCIÓN: MÚSICA Y AMBIENTE SONORO */}
              <div className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-5 shadow-md space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#9a9ab0] flex items-center gap-2">
                  <Music className="w-4 h-4 text-[#ff7ac6]" /> Música y Ambiente Sonoro
                </h3>
                <p className="text-xs text-[#9a9ab0]">
                  Ajusta la ambientación sonora generativa para potenciar tu concentración al escribir.
                </p>

                {/* Switch Música */}
                <div className="p-3.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#252533] flex items-center justify-center text-[#ff7ac6]">
                      {musicaMuted ? <VolumeX className="w-4 h-4 text-[#ff5566]" /> : <Volume2 className="w-4 h-4 text-[#4ade80]" />}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Música de fondo ambiental</div>
                      <div className="text-[11px] text-[#9a9ab0]">
                        {musicaMuted ? 'Música silenciada' : 'Música relajante de autor activa'}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      const next = !musicaMuted;
                      setMusicaMuted(next);
                      audioManager.setMusicMuted(next);
                      if (!next) {
                        audioManager.resumeContext();
                        if (!audioManager.isBgmPlaying) audioManager.startBgm(pistaActual);
                      }
                      showToast(next ? '🔇 Música silenciada' : '🎵 Música activada');
                    }}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      musicaMuted
                        ? 'bg-[#3a3a52] text-[#9a9ab0] hover:text-white'
                        : 'bg-[#4ade80]/20 text-[#4ade80] border border-[#4ade80]/40'
                    }`}
                  >
                    {musicaMuted ? 'Silenciada' : 'Sonando ✓'}
                  </button>
                </div>

                {/* Switch Notificaciones y Sonidos */}
                <div className="p-3.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#252533] flex items-center justify-center text-[#c084fc]">
                      {sonidosMuted ? <BellOff className="w-4 h-4 text-[#ff5566]" /> : <Bell className="w-4 h-4 text-[#7c5cff]" />}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Sonidos de notificaciones y acciones</div>
                      <div className="text-[11px] text-[#9a9ab0]">
                        {sonidosMuted ? 'Efectos sonoros silenciados' : 'Campanas sutiles y sonidos de libro'}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      const next = !sonidosMuted;
                      setSonidosMuted(next);
                      audioManager.setSfxMuted(next);
                      showToast(next ? '🔕 Notificaciones silenciadas' : '🔔 Notificaciones con sonido');
                    }}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      sonidosMuted
                        ? 'bg-[#3a3a52] text-[#9a9ab0] hover:text-white'
                        : 'bg-[#7c5cff]/20 text-[#c084fc] border border-[#7c5cff]/40'
                    }`}
                  >
                    {sonidosMuted ? 'Silenciadas' : 'Sonando ✓'}
                  </button>
                </div>

                {/* Slider Volumen */}
                {!musicaMuted && (
                  <div className="p-3.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-white">Volumen de música</span>
                      <span className="font-mono text-[#c084fc] font-bold">{Math.round(musicaVolumen * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={musicaVolumen}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        setMusicaVolumen(val);
                        audioManager.setMusicVolume(val);
                      }}
                      className="w-full accent-[#7c5cff] cursor-pointer"
                    />
                  </div>
                )}

                {/* Selector de Pistas */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-[#9a9ab0] mb-2">
                    Pista ambiental para escribir
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'mistico', label: '🌌 Inspiración Mística', desc: 'Pads etéreos armónicos' },
                      { id: 'biblioteca', label: '🌧️ Lluvia en Biblioteca', desc: 'Acordes cálidos y serenos' },
                      { id: 'pergamino', label: '📜 Vela y Pergamino', desc: 'Arpegios zen de meditación' }
                    ].map((p) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          setPistaActual(p.id as any);
                          audioManager.startBgm(p.id as any);
                          showToast(`Pista ambiental: ${p.label}`);
                        }}
                        className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                          pistaActual === p.id
                            ? 'bg-[#7c5cff]/20 border-[#7c5cff] text-white shadow-sm'
                            : 'bg-[#2e2e40] border-[#3a3a52] text-[#9a9ab0] hover:text-white'
                        }`}
                      >
                        <div className="text-xs font-bold text-white mb-0.5">{p.label}</div>
                        <div className="text-[10px] text-[#9a9ab0]">{p.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Probar melodia de inicio */}
                <div className="pt-2">
                  <button
                    onClick={() => {
                      audioManager.resumeContext();
                      audioManager.playIntroTheme();
                      showToast('🎶 Reproduciendo melodía de inicio...');
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-bold text-white transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Play className="w-3.5 h-3.5 text-[#ff7ac6]" /> Probar melodía de inicio / apertura
                  </button>
                </div>
              </div>

              {/* SECCIÓN: TEMAS DE COLOR DE FONDO Y ESTÉTICA */}
              <div className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-5 shadow-md space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#9a9ab0] flex items-center gap-2">
                    <Palette className="w-4 h-4 text-[#38bdf8]" /> Temas de Color y Apariencia
                  </h3>
                  <span className="text-[11px] text-[#c084fc] font-semibold">
                    {TEMAS_DISPONIBLES.find((t) => t.id === tema)?.nombre || 'Personalizado'}
                  </span>
                </div>
                <p className="text-xs text-[#9a9ab0]">
                  Selecciona la atmósfera visual que mejor se adapte a tu estado de ánimo o género literario.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {TEMAS_DISPONIBLES.map((t) => {
                    const isSelected = tema === t.id;
                    return (
                      <div
                        key={t.id}
                        onClick={() => {
                          setTema(t.id);
                          showToast(`🎨 Tema aplicado: "${t.nombre}"`);
                        }}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative overflow-hidden group ${
                          isSelected
                            ? 'border-[#7c5cff] ring-2 ring-[#7c5cff]/40 shadow-lg'
                            : 'border-[#3a3a52] hover:border-[#7c5cff]/50 bg-[#2e2e40]/80'
                        }`}
                        style={{ backgroundColor: t.panelPreview }}
                      >
                        {/* Swatch de fondo y acentos */}
                        <div className="flex items-center gap-2 mb-2.5">
                          <div
                            className="w-5 h-5 rounded-full border border-black/30 shadow-sm flex-shrink-0"
                            style={{ backgroundColor: t.bgPreview }}
                            title="Color de fondo"
                          />
                          <div
                            className="w-4 h-4 rounded-full border border-black/20 shadow-sm flex-shrink-0"
                            style={{ backgroundColor: t.accentPreview }}
                            title="Acento 1"
                          />
                          <div
                            className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-sm flex-shrink-0"
                            style={{ backgroundColor: t.accent2Preview }}
                            title="Acento 2"
                          />
                          <span className="ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider bg-black/20 text-[#e8e8f0]/80">
                            {t.tag}
                          </span>
                        </div>

                        <div className="flex items-start justify-between gap-1.5">
                          <div>
                            <div className="text-xs font-bold text-white group-hover:text-[#ff7ac6] transition-colors">
                              {t.nombre}
                            </div>
                            <div className="text-[11px] text-[#9a9ab0] line-clamp-2 mt-0.5 leading-snug">
                              {t.descripcion}
                            </div>
                          </div>
                          {isSelected && (
                            <div className="w-5 h-5 rounded-full bg-[#7c5cff] text-white flex items-center justify-center flex-shrink-0 text-xs shadow-md">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* COPIA DE SEGURIDAD Y FORMATOS */}
              <div className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-5 shadow-md">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#9a9ab0] mb-2 flex items-center gap-2">
                  <Download className="w-4 h-4 text-[#ff7ac6]" /> Copias y Exportación
                </h3>
                <p className="text-xs text-[#9a9ab0] mb-4">
                  Guarda tus personajes y tramas localmente o expórtalos en formatos universales.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    onClick={exportarJSON}
                    className="p-3 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-semibold text-white transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4 text-[#7c5cff]" />
                    <span>Exportar Backup (JSON)</span>
                  </button>

                  <button
                    onClick={exportarMarkdownLibro}
                    className="p-3 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-semibold text-white transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <FileText className="w-4 h-4 text-[#ff7ac6]" />
                    <span>Descargar Ficha (.MD)</span>
                  </button>

                  <label className="p-3 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-semibold text-white transition cursor-pointer flex items-center justify-center gap-2 sm:col-span-2">
                    <Upload className="w-4 h-4 text-[#4ade80]" />
                    <span>Restaurar desde archivo JSON</span>
                    <input
                      type="file"
                      accept=".json"
                      className="hidden"
                      onChange={(e) => e.target.files?.[0] && importarJSON(e.target.files[0])}
                    />
                  </label>
                </div>
              </div>

              {/* EMPAQUETADO APK & GITHUB ACTIONS */}
              <div className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-5 shadow-md space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#9a9ab0] flex items-center gap-2">
                    <span className="text-base">📱</span> Compilación APK & GitHub Actions
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 uppercase">
                    Capacitor Android
                  </span>
                </div>
                <p className="text-xs text-[#9a9ab0]">
                  Descarga el proyecto completo empaquetado en un archivo .ZIP listo para subir a GitHub. GitHub Actions compilará automáticamente el instalador <span className="text-white font-semibold">.apk</span> para tu teléfono Android.
                </p>

                <div className="p-3.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] space-y-3">
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                    <button
                      type="button"
                      onClick={descargarZipProyecto}
                      className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] hover:brightness-110 text-white text-xs font-bold transition flex items-center justify-center gap-2 shadow cursor-pointer text-center"
                    >
                      <Download className="w-4 h-4" />
                      <span>Descargar Proyecto en ZIP (Listo para APK)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(WORKFLOW_YAML_APK);
                        showToast('📋 Workflow YAML copiado al portapapeles');
                      }}
                      className="px-3.5 py-2.5 rounded-xl bg-[#252533] hover:bg-[#34344a] border border-[#3a3a52] text-xs font-bold text-[#e8e8f0] transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5 text-[#38bdf8]" />
                      <span>Copiar Workflow YAML</span>
                    </button>
                  </div>

                  <div className="text-[11px] text-[#9a9ab0] bg-[#1a1a24]/60 p-3 rounded-xl border border-[#3a3a52]/50 space-y-2">
                    <div className="font-semibold text-white flex items-center gap-1.5">
                      <span>💡</span> ¿Tu navegador lo descargó como <span className="text-[#ff5566] font-mono">.zip.html</span>?
                    </div>
                    <p className="text-[#d1d5db] leading-relaxed">
                      Si el archivo se descargó con extensión doble <b className="text-white">.zip.html</b>, se debe a una protección del navegador en vistas previas. <b>Simplemente renombra el archivo descargado y bórralo el <code className="text-[#ff7ac6]">.html</code></b> para que termine en <b className="text-[#4ade80]">.zip</b>. El archivo ya es un ZIP real y completo.
                    </p>
                    <div className="pt-2 border-t border-[#3a3a52]/40 space-y-1.5">
                      <div className="font-semibold text-white flex items-center gap-1.5">
                        <span>🚀</span> Para generar el APK en GitHub (100% automático):
                      </div>
                      <ol className="list-decimal pl-4 space-y-1 text-[#9a9ab0]">
                        <li>Crea un repositorio en GitHub y sube los archivos de este ZIP.</li>
                        <li>GitHub Actions ejecutará automáticamente <code className="text-[#38bdf8] font-mono">build-apk.yml</code>.</li>
                        <li>Ve a la pestaña <b>Actions</b> y descarga el artefacto <b>BibliaDeEscritura-Instalador-APK</b> (.apk directo a tu celular).</li>
                      </ol>

                      <div className="font-semibold text-white pt-1 flex items-center gap-1.5">
                        <span>🤖</span> Si abres el proyecto en Android Studio:
                      </div>
                      <p className="text-[#9a9ab0] leading-relaxed">
                        Abre específicamente la carpeta <code className="text-[#38bdf8] font-mono">android/</code> dentro de Android Studio (no la carpeta raíz del proyecto). Hemos integrado el módulo nativo de Capacitor directamente en el proyecto para que Gradle sincronice sin errores. Asegúrate de tener seleccionado <b>Java 17 o 21</b> en <i>Settings → Build Tools → Gradle → Gradle JDK</i>.
                      </p>
                    </div>
                  </div>

                </div>
              </div>

              {/* INFORMACIÓN DEL ESTUDIO */}
              <div className="rounded-2xl bg-[#252533] border border-[#3a3a52] p-5 shadow-md">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#9a9ab0] mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#facc15]" /> Estadísticas
                </h3>
                <div className="divide-y divide-[#3a3a52]/60 text-xs">
                  <div className="py-2.5 flex justify-between">
                    <span className="text-[#9a9ab0]">Libros totales</span>
                    <span className="font-mono font-bold text-white">{state.novelas.length}</span>
                  </div>
                  <div className="py-2.5 flex justify-between">
                    <span className="text-[#9a9ab0]">Personajes creados</span>
                    <span className="font-mono font-bold text-white">
                      {state.novelas.reduce((acc, n) => acc + n.personajes.length, 0)}
                    </span>
                  </div>
                  <div className="py-2.5 flex justify-between">
                    <span className="text-[#9a9ab0]">Vínculos de relación</span>
                    <span className="font-mono font-bold text-white">
                      {state.novelas.reduce(
                        (acc, n) => acc + n.personajes.reduce((pacc, p) => pacc + (p.relaciones?.length || 0), 0),
                        0
                      )}
                    </span>
                  </div>
                  <div className="py-2.5 flex justify-between">
                    <span className="text-[#9a9ab0]">Almacenamiento local</span>
                    <span className="font-mono font-bold text-[#c084fc]">
                      {(localStorage.getItem(STORAGE_KEY)?.length || 0) > 1024
                        ? `${((localStorage.getItem(STORAGE_KEY)?.length || 0) / 1024).toFixed(1)} KB`
                        : `${localStorage.getItem(STORAGE_KEY)?.length || 0} bytes`}
                    </span>
                  </div>
                </div>
              </div>

              {/* ZONA DE PELIGRO */}
              <div className="rounded-2xl bg-[#252533] border border-[#ff5566]/30 p-5 shadow-md">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#ff5566] mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Zona peligrosa
                </h3>
                <p className="text-xs text-[#9a9ab0] mb-4">
                  Estas acciones no se pueden deshacer. Asegúrate de tener una copia de respaldo.
                </p>
                <div className="flex flex-wrap gap-2.5">
                  {novelaActiva && (
                    <button
                      onClick={() => borrarLibro(novelaActiva.id)}
                      className="px-4 py-2 rounded-xl bg-[#ff5566]/10 hover:bg-[#ff5566]/20 border border-[#ff5566]/40 text-xs font-semibold text-[#ff8a96] transition cursor-pointer"
                    >
                      Borrar "{novelaActiva.nombre}"
                    </button>
                  )}
                  <button
                    onClick={() => {
                      if (!confirm('¿Borrar TODOS los libros y personajes? Se reiniciará toda la aplicación.')) return;
                      localStorage.removeItem(STORAGE_KEY);
                      localStorage.removeItem(LEGACY_STORAGE_KEY);
                      window.location.reload();
                    }}
                    className="px-4 py-2 rounded-xl bg-[#ff5566]/20 hover:bg-[#ff5566]/30 border border-[#ff5566]/60 text-xs font-bold text-[#ff8a96] transition cursor-pointer"
                  >
                    Restablecer todo a cero
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* =========================================================
          MENÚ INFERIOR FIJO (5 BOTONES CON HOME DESTACADO)
          ========================================================= */}
      <nav className="fixed bottom-0 left-0 right-0 h-[72px] sm:h-[76px] bg-gradient-to-b from-[#24243a] to-[#1c1c2b] border-t border-[#3a3a52] flex items-center justify-around z-40 px-2 sm:px-4 shadow-[0_-6px_25px_rgba(0,0,0,0.45)] pb-[env(safe-area-inset-bottom,4px)]">
        {/* BOTON 1: CONFIG */}
        <button
          onClick={() => cambiarVista('config')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold transition cursor-pointer ${
            state.vistaActiva === 'config' ? 'text-[#ff7ac6]' : 'text-[#9a9ab0] hover:text-white'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span>Config</span>
        </button>

        {/* BOTON 2: TRAMA */}
        <button
          onClick={() => cambiarVista('trama')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold transition cursor-pointer ${
            state.vistaActiva === 'trama' ? 'text-[#ff7ac6]' : 'text-[#9a9ab0] hover:text-white'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span>Trama</span>
        </button>

        {/* BOTON 3: HOME / ELENCO (DESTACADO CENTRAL) */}
        <button
          onClick={() => cambiarVista('home')}
          className={`relative -top-3.5 w-16 h-16 sm:w-17 sm:h-17 rounded-full flex flex-col items-center justify-center gap-0.5 text-[10px] font-black text-white shadow-[0_8px_24px_rgba(124,92,255,0.6)] border-4 border-[#1c1c2b] transition-all hover:scale-105 active:scale-95 cursor-pointer ${
            state.vistaActiva === 'home'
              ? 'bg-gradient-to-tr from-[#7c5cff] to-[#ff7ac6] ring-2 ring-[#ff7ac6]'
              : 'bg-gradient-to-tr from-[#5839db] to-[#e054a3]'
          }`}
        >
          <Users className="w-6 h-6 drop-shadow" />
          <span>Elenco</span>
        </button>

        {/* BOTON 4: CONEXIONES */}
        <button
          onClick={() => cambiarVista('conexiones')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold transition cursor-pointer ${
            state.vistaActiva === 'conexiones' ? 'text-[#ff7ac6]' : 'text-[#9a9ab0] hover:text-white'
          }`}
        >
          <GitFork className="w-5 h-5" />
          <span>Conexiones</span>
        </button>

        {/* BOTON 5: LUGARES */}
        <button
          onClick={() => cambiarVista('lugares')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold transition cursor-pointer ${
            state.vistaActiva === 'lugares' ? 'text-[#ff7ac6]' : 'text-[#9a9ab0] hover:text-white'
          }`}
        >
          <Compass className="w-5 h-5" />
          <span>Lugares</span>
        </button>
      </nav>

      {/* =========================================================
          MODAL: NUEVO PERSONAJE
          ========================================================= */}
      {modalNuevoPersonaje && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-2xl bg-[#252533] border border-[#3a3a52] rounded-2xl shadow-2xl flex flex-col max-h-[88vh] sm:max-h-[86vh] my-auto animate-modal-in overflow-hidden">
            <div className="p-4 sm:px-6 border-b border-[#3a3a52] bg-gradient-to-r from-[#7c5cff]/15 to-[#ff7ac6]/10 flex items-center justify-between flex-shrink-0">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>✍️</span> Nuevo personaje para "{novelaActiva?.nombre}"
              </h3>
              <button
                onClick={() => setModalNuevoPersonaje(false)}
                className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                guardarNuevoPersonaje({
                  nombre: (form.elements.namedItem('np_nombre') as HTMLInputElement).value,
                  rol: (form.elements.namedItem('np_rol') as HTMLInputElement).value,
                  edad: (form.elements.namedItem('np_edad') as HTMLInputElement).value,
                  origen: (form.elements.namedItem('np_origen') as HTMLInputElement).value,
                  ocupacion: (form.elements.namedItem('np_ocupacion') as HTMLInputElement).value,
                  aliados: (form.elements.namedItem('np_aliados') as HTMLInputElement).value,
                  caracteristicas: (form.elements.namedItem('np_caracteristicas') as HTMLTextAreaElement).value,
                  historia: (form.elements.namedItem('np_historia') as HTMLTextAreaElement).value,
                  notas: (form.elements.namedItem('np_notas') as HTMLTextAreaElement).value
                });
              }}
              className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Nombre del Personaje *
                  </label>
                  <input
                    name="np_nombre"
                    type="text"
                    required
                    placeholder="Ej: Daniel Vane"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Rol / Arquetipo
                  </label>
                  <input
                    name="np_rol"
                    type="text"
                    placeholder="Protagonista, Antagonista, Mentor..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Edad / Época
                  </label>
                  <input
                    name="np_edad"
                    type="text"
                    placeholder="Ej: 28 años, siglo XIX, época dorada..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Origen / Lugar de nacimiento
                  </label>
                  <input
                    name="np_origen"
                    type="text"
                    placeholder="Ciudad, provincia, reino o planeta..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Ocupación / Oficio
                  </label>
                  <input
                    name="np_ocupacion"
                    type="text"
                    placeholder="Detective, alquimista, capitán de barco..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Aliados / Red de confianza
                  </label>
                  <input
                    name="np_aliados"
                    type="text"
                    placeholder="Nombres o facciones afines..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Características físicas y psicológicas
                  </label>
                  <textarea
                    name="np_caracteristicas"
                    rows={2}
                    placeholder="Apariencia, altura, mirada, manías, virtudes y defectos..."
                    className="w-full px-3.5 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff] resize-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Historia / Trasfondo
                  </label>
                  <textarea
                    name="np_historia"
                    rows={3}
                    placeholder="Origen, sucesos del pasado que lo marcaron, secretos familiares..."
                    className="w-full px-3.5 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff] resize-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Notas y detalles clave
                  </label>
                  <textarea
                    name="np_notas"
                    rows={2}
                    placeholder="Cosas que no quieres olvidar en los capítulos venideros..."
                    className="w-full px-3.5 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff] resize-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-[#3a3a52]">
                <button
                  type="button"
                  onClick={() => setModalNuevoPersonaje(false)}
                  className="px-4 py-2 rounded-xl text-sm font-semibold bg-transparent border border-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-xl text-sm font-semibold bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] text-white hover:brightness-110 cursor-pointer shadow-md"
                >
                  💾 Guardar personaje
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: EDITAR PERSONAJE
          ========================================================= */}
      {modalEditarPersonaje && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-2xl bg-[#252533] border border-[#3a3a52] rounded-2xl shadow-2xl flex flex-col max-h-[88vh] sm:max-h-[86vh] my-auto animate-modal-in overflow-hidden">
            <div className="p-4 sm:px-6 border-b border-[#3a3a52] bg-gradient-to-r from-[#7c5cff]/15 to-[#ff7ac6]/10 flex items-center justify-between flex-shrink-0">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>✏️</span> Editar a "{modalEditarPersonaje.nombre}"
              </h3>
              <button
                onClick={() => setModalEditarPersonaje(null)}
                className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                guardarEdicionPersonaje({
                  ...modalEditarPersonaje,
                  nombre: (form.elements.namedItem('ed_nombre') as HTMLInputElement).value,
                  rol: (form.elements.namedItem('ed_rol') as HTMLInputElement).value,
                  edad: (form.elements.namedItem('ed_edad') as HTMLInputElement).value,
                  origen: (form.elements.namedItem('ed_origen') as HTMLInputElement).value,
                  ocupacion: (form.elements.namedItem('ed_ocupacion') as HTMLInputElement).value,
                  aliados: (form.elements.namedItem('ed_aliados') as HTMLInputElement).value,
                  caracteristicas: (form.elements.namedItem('ed_caracteristicas') as HTMLTextAreaElement).value,
                  historia: (form.elements.namedItem('ed_historia') as HTMLTextAreaElement).value,
                  notas: (form.elements.namedItem('ed_notas') as HTMLTextAreaElement).value
                });
              }}
              className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Nombre del Personaje *
                  </label>
                  <input
                    name="ed_nombre"
                    type="text"
                    required
                    defaultValue={modalEditarPersonaje.nombre}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Rol / Arquetipo
                  </label>
                  <input
                    name="ed_rol"
                    type="text"
                    defaultValue={modalEditarPersonaje.rol || ''}
                    placeholder="Protagonista, Antagonista, Mentor..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Edad / Época
                  </label>
                  <input
                    name="ed_edad"
                    type="text"
                    defaultValue={modalEditarPersonaje.edad || ''}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Origen / Lugar
                  </label>
                  <input
                    name="ed_origen"
                    type="text"
                    defaultValue={modalEditarPersonaje.origen || ''}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Ocupación / Oficio
                  </label>
                  <input
                    name="ed_ocupacion"
                    type="text"
                    defaultValue={modalEditarPersonaje.ocupacion || ''}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Aliados
                  </label>
                  <input
                    name="ed_aliados"
                    type="text"
                    defaultValue={modalEditarPersonaje.aliados || ''}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Características físicas y psicológicas
                  </label>
                  <textarea
                    name="ed_caracteristicas"
                    rows={2}
                    defaultValue={modalEditarPersonaje.caracteristicas || ''}
                    className="w-full px-3.5 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff] resize-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Historia / Trasfondo
                  </label>
                  <textarea
                    name="ed_historia"
                    rows={3}
                    defaultValue={modalEditarPersonaje.historia || ''}
                    className="w-full px-3.5 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff] resize-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] uppercase font-bold text-[#9a9ab0] mb-1">
                    Notas y detalles clave
                  </label>
                  <textarea
                    name="ed_notas"
                    rows={2}
                    defaultValue={modalEditarPersonaje.notas || ''}
                    className="w-full px-3.5 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-sm focus:outline-none focus:border-[#7c5cff] resize-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-[#3a3a52]">
                <button
                  type="button"
                  onClick={() => setModalEditarPersonaje(null)}
                  className="px-4 py-2 rounded-xl text-sm font-semibold bg-transparent border border-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-xl text-sm font-semibold bg-gradient-to-r from-[#7c5cff] to-[#ff7ac6] text-white hover:brightness-110 cursor-pointer shadow-md"
                >
                  💾 Guardar cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: GESTIONAR RELACIONES
          ========================================================= */}
      {modalRelaciones && novelaActiva && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3 sm:p-5">
          <div className="w-full max-w-lg bg-[#252533] border border-[#3a3a52] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] animate-modal-in overflow-hidden">
            <div className="p-4 border-b border-[#3a3a52] flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <GitFork className="w-4 h-4 text-[#ff7ac6]" /> Relaciones de "{modalRelaciones.nombre}"
              </h3>
              <button
                onClick={() => setModalRelaciones(null)}
                className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 flex-1 overflow-y-auto space-y-4">
              {/* VINCULOS EXISTENTES */}
              <div>
                <h4 className="text-xs uppercase font-bold text-[#9a9ab0] mb-2">Vínculos actuales</h4>
                {(!modalRelaciones.relaciones || modalRelaciones.relaciones.length === 0) ? (
                  <p className="text-xs text-[#646482] italic">Este personaje no tiene relaciones registradas.</p>
                ) : (
                  <div className="space-y-2">
                    {modalRelaciones.relaciones.map((r) => {
                      const dest = novelaActiva.personajes.find((x) => x.id === r.destinoId);
                      return (
                        <div
                          key={r.id}
                          className="p-2.5 rounded-xl bg-[#2e2e40] border border-[#3a3a52] flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="min-w-0">
                            <div className="font-bold text-white flex items-center gap-1.5">
                              <span className="text-[#ff7ac6]">{r.tipo}</span>
                              <span className="text-[#9a9ab0]">→</span>
                              <span>{dest ? dest.nombre : '(Eliminado)'}</span>
                            </div>
                            {r.notas && <div className="text-[11px] text-[#9a9ab0] italic">"{r.notas}"</div>}
                          </div>
                          <button
                            onClick={() => eliminarRelacion(modalRelaciones.id, r.id)}
                            className="p-1 rounded text-[#ff5566] hover:bg-[#ff5566]/15 cursor-pointer"
                            title="Eliminar vínculo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* FORMULARIO AGREGAR VINCULO */}
              <div className="pt-3 border-t border-[#3a3a52]">
                <h4 className="text-xs uppercase font-bold text-[#9a9ab0] mb-2 flex items-center gap-1.5">
                  <Plus className="w-3.5 h-3.5 text-[#7c5cff]" /> Añadir nueva conexión
                </h4>

                {novelaActiva.personajes.filter((p) => p.id !== modalRelaciones.id).length === 0 ? (
                  <p className="text-xs text-[#9a9ab0]">No hay otros personajes disponibles para conectar.</p>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const destinoId = (form.elements.namedItem('rel_destino') as HTMLSelectElement).value;
                      const tipo = (form.elements.namedItem('rel_tipo') as HTMLInputElement).value;
                      const notas = (form.elements.namedItem('rel_notas') as HTMLInputElement).value;
                      agregarRelacion(modalRelaciones.id, destinoId, tipo, notas);
                      form.reset();
                    }}
                    className="space-y-3"
                  >
                    <div>
                      <label className="block text-[11px] text-[#9a9ab0] mb-1">Hacia el personaje:</label>
                      <select
                        name="rel_destino"
                        required
                        className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                      >
                        {novelaActiva.personajes
                          .filter((p) => p.id !== modalRelaciones.id)
                          .map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.nombre} ({p.rol || 'Sin rol'})
                            </option>
                          ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] text-[#9a9ab0] mb-1">Tipo de relación:</label>
                      <input
                        name="rel_tipo"
                        type="text"
                        list="tipos-rel"
                        required
                        placeholder="Ej: Aliado, Hermano de, Rival de, Romance..."
                        className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                      />
                      <datalist id="tipos-rel">
                        {TIPOS_RELACION_PREDEFINIDOS.map((t) => (
                          <option key={t} value={t} />
                        ))}
                      </datalist>
                    </div>

                    <div>
                      <label className="block text-[11px] text-[#9a9ab0] mb-1">Notas del vínculo (opcional):</label>
                      <input
                        name="rel_notas"
                        type="text"
                        placeholder="Ej: Se conocen desde niños; juramento de honor..."
                        className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2 rounded-xl bg-[#7c5cff] hover:bg-[#6b4dec] text-white text-xs font-bold transition cursor-pointer shadow"
                    >
                      + Vincular personajes
                    </button>
                  </form>
                )}
              </div>
            </div>

            <div className="p-3 border-t border-[#3a3a52] flex justify-end">
              <button
                onClick={() => setModalRelaciones(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-[#2e2e40] text-white hover:bg-[#34344a] cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: MOVER PERSONAJE A OTRO LIBRO
          ========================================================= */}
      {modalMoverPersonaje && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#252533] border border-[#3a3a52] rounded-2xl shadow-2xl p-5 animate-modal-in">
            <div className="flex items-center justify-between pb-3 border-b border-[#3a3a52] mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>📁</span> Transferir a otro libro
              </h3>
              <button
                onClick={() => setModalMoverPersonaje(null)}
                className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-[#9a9ab0] mb-3">
              Selecciona a qué libro quieres trasladar a <b className="text-white">"{modalMoverPersonaje.nombre}"</b>:
            </p>

            <div className="space-y-2 max-h-60 overflow-y-auto mb-4">
              {state.novelas.filter((n) => n.id !== state.novelaActivaId).length === 0 ? (
                <div className="p-4 text-center text-xs text-[#9a9ab0] bg-[#2e2e40] rounded-xl border border-[#3a3a52]">
                  No tienes otros libros. Crea uno nuevo antes de transferir.
                </div>
              ) : (
                state.novelas
                  .filter((n) => n.id !== state.novelaActivaId)
                  .map((n) => (
                    <button
                      key={n.id}
                      onClick={() => moverPersonajeDestino(n.id)}
                      className="w-full p-3 rounded-xl bg-[#2e2e40] hover:bg-[#34344a] border border-[#3a3a52] hover:border-[#7c5cff] text-left flex items-center gap-3 transition cursor-pointer group"
                    >
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: n.color }} />
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-white text-xs truncate group-hover:text-[#ff7ac6]">
                          {n.nombre}
                        </div>
                        <div className="text-[10px] text-[#9a9ab0]">
                          {n.personajes.length} personajes actuales
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-[#9a9ab0] group-hover:text-white flex-shrink-0" />
                    </button>
                  ))
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setModalMoverPersonaje(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-transparent border border-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: CONFIRMAR ELIMINAR PERSONAJE
          ========================================================= */}
      {modalEliminarPersonaje && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#252533] border border-[#ff5566]/40 rounded-2xl shadow-2xl p-5 animate-modal-in">
            <h3 className="text-base font-bold text-white flex items-center gap-2 mb-2">
              <Trash2 className="w-5 h-5 text-[#ff5566]" /> ¿Eliminar personaje?
            </h3>
            <p className="text-xs text-[#9a9ab0] mb-3">
              ¿Estás seguro de que quieres eliminar a <b className="text-white">"{modalEliminarPersonaje.nombre}"</b>?
            </p>
            <p className="text-xs text-[#ff8a96] mb-5 bg-[#ff5566]/10 p-2.5 rounded-xl border border-[#ff5566]/20">
              Esta acción no se puede deshacer y borrará también sus conexiones con otros personajes.
            </p>

            <div className="flex justify-end gap-2.5">
              <button
                onClick={() => setModalEliminarPersonaje(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-transparent border border-[#3a3a52] text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={confirmarEliminarPersonaje}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#ff5566] text-white hover:bg-[#e04052] transition cursor-pointer shadow-md"
              >
                Sí, eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: NUEVO / EDITAR CAPÍTULO
          ========================================================= */}
      {(modalNuevoCapitulo || modalEditarCapitulo) && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#252533] border border-[#3a3a52] rounded-2xl shadow-2xl p-5 animate-modal-in">
            <div className="flex items-center justify-between pb-3 border-b border-[#3a3a52] mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#7c5cff]" />
                {modalEditarCapitulo ? 'Editar Capítulo' : 'Nuevo Capítulo / Escena'}
              </h3>
              <button
                onClick={() => {
                  setModalNuevoCapitulo(false);
                  setModalEditarCapitulo(null);
                }}
                className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                guardarCapitulo({
                  numero: Number((form.elements.namedItem('cap_numero') as HTMLInputElement).value),
                  titulo: (form.elements.namedItem('cap_titulo') as HTMLInputElement).value,
                  resumen: (form.elements.namedItem('cap_resumen') as HTMLTextAreaElement).value,
                  estado: (form.elements.namedItem('cap_estado') as HTMLSelectElement).value as any,
                  notas: (form.elements.namedItem('cap_notas') as HTMLInputElement).value
                });
              }}
              className="space-y-3"
            >
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Número:</label>
                  <input
                    name="cap_numero"
                    type="number"
                    min="1"
                    defaultValue={modalEditarCapitulo?.numero || (novelaActiva?.capitulos?.length || 0) + 1}
                    className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Estado:</label>
                  <select
                    name="cap_estado"
                    defaultValue={modalEditarCapitulo?.estado || 'Borrador'}
                    className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                  >
                    <option value="Borrador">Borrador</option>
                    <option value="En revisión">En revisión</option>
                    <option value="Finalizado">Finalizado</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Título del capítulo *</label>
                <input
                  name="cap_titulo"
                  type="text"
                  required
                  defaultValue={modalEditarCapitulo?.titulo || ''}
                  placeholder="Ej: La emboscada del puente"
                  className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Resumen de la trama:</label>
                <textarea
                  name="cap_resumen"
                  rows={4}
                  defaultValue={modalEditarCapitulo?.resumen || ''}
                  placeholder="¿Qué ocurre en este capítulo? ¿Cuál es el giro o revelación?"
                  className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff] resize-none"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Notas adicionales:</label>
                <input
                  name="cap_notas"
                  type="text"
                  defaultValue={modalEditarCapitulo?.notas || ''}
                  placeholder="Pistas a sembrar, ritmo, tono..."
                  className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => {
                    setModalNuevoCapitulo(false);
                    setModalEditarCapitulo(null);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-transparent border border-[#3a3a52] text-[#9a9ab0]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 rounded-xl text-xs font-bold bg-[#7c5cff] hover:bg-[#6b4dec] text-white cursor-pointer"
                >
                  Guardar capítulo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: NUEVO / EDITAR LUGAR
          ========================================================= */}
      {(modalNuevoLugar || modalEditarLugar) && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#252533] border border-[#3a3a52] rounded-2xl shadow-2xl p-5 animate-modal-in">
            <div className="flex items-center justify-between pb-3 border-b border-[#3a3a52] mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#38bdf8]" />
                {modalEditarLugar ? 'Editar Lugar' : 'Nuevo Lugar del Mundo'}
              </h3>
              <button
                onClick={() => {
                  setModalNuevoLugar(false);
                  setModalEditarLugar(null);
                }}
                className="p-1 rounded text-[#9a9ab0] hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                guardarLugar({
                  nombre: (form.elements.namedItem('lug_nombre') as HTMLInputElement).value,
                  tipo: (form.elements.namedItem('lug_tipo') as HTMLInputElement).value,
                  descripcion: (form.elements.namedItem('lug_descripcion') as HTMLTextAreaElement).value,
                  atmosfera: (form.elements.namedItem('lug_atmosfera') as HTMLInputElement).value
                });
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Nombre del lugar *</label>
                <input
                  name="lug_nombre"
                  type="text"
                  required
                  defaultValue={modalEditarLugar?.nombre || ''}
                  placeholder="Ej: Fortaleza de Sombragris"
                  className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Tipo de ubicación:</label>
                <input
                  name="lug_tipo"
                  type="text"
                  defaultValue={modalEditarLugar?.tipo || ''}
                  placeholder="Ciudad, Reino, Taberna, Bosque, Fortaleza..."
                  className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Descripción y detalles:</label>
                <textarea
                  name="lug_descripcion"
                  rows={3}
                  defaultValue={modalEditarLugar?.descripcion || ''}
                  placeholder="Arquitectura, defensas, historia, secretos del lugar..."
                  className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff] resize-none"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#9a9ab0] mb-1 font-semibold">Atmósfera y sensaciones:</label>
                <input
                  name="lug_atmosfera"
                  type="text"
                  defaultValue={modalEditarLugar?.atmosfera || ''}
                  placeholder="Olores, sonidos, iluminación, clima..."
                  className="w-full px-3 py-2 rounded-xl bg-[#2e2e40] border border-[#3a3a52] text-white text-xs focus:outline-none focus:border-[#7c5cff]"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => {
                    setModalNuevoLugar(false);
                    setModalEditarLugar(null);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-transparent border border-[#3a3a52] text-[#9a9ab0]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 rounded-xl text-xs font-bold bg-[#7c5cff] hover:bg-[#6b4dec] text-white cursor-pointer"
                >
                  Guardar lugar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================
          MENÚ CONTEXTUAL FLOTANTE (⋯)
          ========================================================= */}
      {ctxMenu && novelaActiva && (
        <div
          style={{ top: ctxMenu.y, left: ctxMenu.x }}
          className="fixed z-50 w-52 bg-[#2e2e40] border border-[#3a3a52] rounded-xl p-1.5 shadow-2xl animate-fade-in text-xs font-medium space-y-0.5"
          onClick={(e) => e.stopPropagation()}
        >
          {(() => {
            const p = novelaActiva.personajes.find((x) => x.id === ctxMenu.pId);
            if (!p) return null;

            return (
              <>
                <button
                  onClick={() => {
                    setModalEditarPersonaje(p);
                    setCtxMenu(null);
                  }}
                  className="w-full p-2 rounded-lg text-left text-white hover:bg-[#3a3a55] flex items-center gap-2 cursor-pointer transition"
                >
                  <Edit3 className="w-3.5 h-3.5 text-[#ff7ac6]" /> Editar ficha
                </button>

                <button
                  onClick={() => {
                    setModalRelaciones(p);
                    setCtxMenu(null);
                  }}
                  className="w-full p-2 rounded-lg text-left text-white hover:bg-[#3a3a55] flex items-center gap-2 cursor-pointer transition"
                >
                  <GitFork className="w-3.5 h-3.5 text-[#7c5cff]" /> Gestionar vínculos
                </button>

                <button
                  onClick={() => {
                    duplicarPersonaje(p.id);
                    setCtxMenu(null);
                  }}
                  className="w-full p-2 rounded-lg text-left text-white hover:bg-[#3a3a55] flex items-center gap-2 cursor-pointer transition"
                >
                  <Copy className="w-3.5 h-3.5 text-[#facc15]" /> Duplicar personaje
                </button>

                <button
                  onClick={() => {
                    setModalMoverPersonaje(p);
                    setCtxMenu(null);
                  }}
                  className="w-full p-2 rounded-lg text-left text-white hover:bg-[#3a3a55] flex items-center gap-2 cursor-pointer transition"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#38bdf8]" /> Enviar a otro libro
                </button>

                <div className="h-px bg-[#3a3a52] my-1" />

                <button
                  onClick={() => {
                    setModalEliminarPersonaje(p);
                    setCtxMenu(null);
                  }}
                  className="w-full p-2 rounded-lg text-left text-[#ff8a96] hover:bg-[#ff5566]/20 flex items-center gap-2 cursor-pointer transition"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Eliminar personaje
                </button>
              </>
            );
          })()}
        </div>
      )}

      {/* =========================================================
          TOAST FEEDBACK
          ========================================================= */}
      {toast && (
        <div
          className={`fixed bottom-22 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl text-xs font-bold text-white shadow-2xl flex items-center gap-2 animate-fade-in pointer-events-none transition-all ${
            toast.type === 'err'
              ? 'bg-[#ff5566] border border-[#ff8a96]'
              : toast.type === 'warn'
              ? 'bg-[#d97706] border border-[#f59e0b]'
              : 'bg-[#7c5cff] border border-[#ff7ac6]/50 shadow-[0_0_20px_rgba(124,92,255,0.6)]'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{toast.msg}</span>
        </div>
      )}
    </div>
  );
}
